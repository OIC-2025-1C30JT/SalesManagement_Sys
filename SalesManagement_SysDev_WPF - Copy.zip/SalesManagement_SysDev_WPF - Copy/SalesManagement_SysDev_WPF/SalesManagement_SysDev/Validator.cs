﻿namespace SalesManagement_SysDev
{
    public static class Validator
    {
        // 密码规则：半角英数字 3～10 文字（EmPassword 是 NVARCHAR(10)）
        public static bool IsValidPassword(string password)
        {
            if (string.IsNullOrEmpty(password)) return false;
            if (password.Length < 3 || password.Length > 10) return false;

            foreach (char c in password)
            {
                bool isAlnum = (c >= '0' && c <= '9') ||
                               (c >= 'a' && c <= 'z') ||
                               (c >= 'A' && c <= 'Z');
                if (!isAlnum) return false;
            }
            return true;
        }

        public const string PasswordRuleText = "パスワードは半角英数字3～10文字で入力してください";
        // 電話番号：半角数字とハイフンのみ、13文字以内（EmPhone は NVARCHAR(13)）
        public static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrEmpty(phone)) return false;
            if (phone.Length > 13) return false;

            foreach (char c in phone)
            {
                bool ok = (c >= '0' && c <= '9') || c == '-';
                if (!ok) return false;
            }
            return true;
        }

        // 郵便番号：半角数字7桁（ClPostal は NVARCHAR(7)）
        public static bool IsValidPostal(string postal)
        {
            if (string.IsNullOrEmpty(postal)) return false;
            if (postal.Length != 7) return false;

            foreach (char c in postal)
            {
                if (c < '0' || c > '9') return false;
            }
            return true;
        }
        // JANコード：半角数字13桁（PrJCode は NVARCHAR(13)、任意項目なので空欄は呼び出し側で許可）
        public static bool IsValidJanCode(string code)
        {
            if (code.Length != 13) return false;

            foreach (char c in code)
            {
                if (c < '0' || c > '9') return false;
            }
            return true;
        }

            

        public const string JanRuleText = "JANコードは半角数字13桁で入力してください（未入力も可）";


        public const string PostalRuleText = "郵便番号は半角数字7桁（ハイフンなし）で入力してください";


        public const string PhoneRuleText = "電話番号は半角数字とハイフンで、13文字以内で入力してください";
    }
}