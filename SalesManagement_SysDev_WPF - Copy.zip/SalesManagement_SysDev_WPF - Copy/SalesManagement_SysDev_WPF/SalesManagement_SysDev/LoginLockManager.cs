﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesManagement_SysDev
{
    internal class LoginLockManager
    { // 密码连续错误5次，锁定15分钟（记录在内存中）
       
        
            private const int MaxFailCount = 5;
            private const int LockMinutes = 15;

            private static Dictionary<string, int> failCounts = new Dictionary<string, int>();
            private static Dictionary<string, DateTime> lockUntil = new Dictionary<string, DateTime>();

            // 检查是否锁定中，remainMinutes 返回剩余分钟（向上取整）
            public static bool IsLocked(string id, out int remainMinutes)
            {
                remainMinutes = 0;
                string key = id.ToLower();

                if (!lockUntil.ContainsKey(key))
                {
                    return false;
                }

                DateTime until = lockUntil[key];
                if (DateTime.Now >= until)
                {
                    // 锁定时间已过，解除
                    lockUntil.Remove(key);
                    failCounts.Remove(key);
                    return false;
                }

                remainMinutes = (int)Math.Ceiling((until - DateTime.Now).TotalMinutes);
                return true;
            }

            // 记录一次失败，返回 true 表示这次失败导致账户被锁定
            public static bool RecordFail(string id)
            {
                string key = id.ToLower();

                if (!failCounts.ContainsKey(key))
                {
                    failCounts[key] = 0;
                }
                failCounts[key]++;

                if (failCounts[key] >= MaxFailCount)
                {
                    lockUntil[key] = DateTime.Now.AddMinutes(LockMinutes);
                    return true;
                }
                return false;
            }

            // 返回还剩几次机会
            public static int RemainTries(string id)
            {
                string key = id.ToLower();
                int count = failCounts.ContainsKey(key) ? failCounts[key] : 0;
                return MaxFailCount - count;
            }

            // 登录成功后清除失败记录
            public static void Reset(string id)
            {
                string key = id.ToLower();
                failCounts.Remove(key);
                lockUntil.Remove(key);
            }
        }
    }


