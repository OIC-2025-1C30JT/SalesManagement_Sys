﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_SaleHistory : Window
    {
        private List<SaleHistoryRow> currentSales =
            new List<SaleHistoryRow>();

        private List<MonthlySaleRow> currentMonths =
            new List<MonthlySaleRow>();

        private string currentPeriod = "全期間";

        // =====================================
        // 売上履歴表示用
        // =====================================
        private class SaleHistoryRow
        {
            public int SaId { get; set; }

            public DateTime SaDate { get; set; }

            public int ClId { get; set; }

            public int SoId { get; set; }

            public int EmId { get; set; }

            public int OrId { get; set; }

            public decimal Total { get; set; }
        }

        // =====================================
        // 月別集計表示用
        // =====================================
        private class MonthlySaleRow
        {
            public string MonthText { get; set; } = "";

            public int Count { get; set; }

            public decimal Total { get; set; }
        }

        // =====================================
        // Constructor
        // =====================================
        public F_SaleHistory()
        {
            InitializeComponent();
        }

        // =====================================
        // 画面起動
        // =====================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            // 初期表示：今日の日付
            DateTime today = DateTime.Today;

            dpFrom.SelectedDate = today;
            dpTo.SelectedDate = today;

            SearchSelectedDates();
        }

        // =====================================
        // 検索ボタン
        // =====================================
        private void btnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            SearchSelectedDates();
        }

        // =====================================
        // 日付範囲検索
        // =====================================
        private void SearchSelectedDates()
        {
            if (!dpFrom.SelectedDate.HasValue ||
                !dpTo.SelectedDate.HasValue)
            {
                MessageBox.Show(
                    "開始日と終了日を選択してください。",
                    "入力確認",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // 開始日
            DateTime from =
                dpFrom.SelectedDate.Value.Date;

            // 終了日
            DateTime to =
                dpTo.SelectedDate.Value.Date;

            // 開始日 > 終了日はエラー
            if (from > to)
            {
                MessageBox.Show(
                    "開始日は終了日以前にしてください。",
                    "入力確認",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // 終了日の翌日を上限にする
            // 例：
            // 2026/11/20 ～ 2026/11/20
            //
            // SaDate >= 2026/11/20 00:00
            // SaDate <  2026/11/21 00:00

            DateTime endExclusive = to.AddDays(1);

            string period =
                $"{from:yyyy/MM/dd} ～ {to:yyyy/MM/dd}";

            LoadHistory(
                from,
                endExclusive,
                period);
        }

        // =====================================
        // 全件表示
        // =====================================
        private void btnAll_Click(
            object sender,
            RoutedEventArgs e)
        {
            dpFrom.SelectedDate = null;
            dpTo.SelectedDate = null;

            LoadHistory(
                null,
                null,
                "全期間");
        }

        // =====================================
        // データベースから売上履歴取得
        // =====================================
        private void LoadHistory(
            DateTime? from,
            DateTime? endExclusive,
            string period)
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query = context.TSales
                    .AsNoTracking()
                    .AsQueryable();

                // 開始日以降
                if (from.HasValue)
                {
                    DateTime startDate = from.Value;

                    query = query.Where(
                        x => x.SaDate >= startDate);
                }

                // 終了日の翌日より前
                if (endExclusive.HasValue)
                {
                    DateTime endDate =
                        endExclusive.Value;

                    query = query.Where(
                        x => x.SaDate < endDate);
                }

                // 売上データ取得
                var sales = query
                    .OrderBy(x => x.SaDate)
                    .ThenBy(x => x.SaId)
                    .ToList();

                // 売上ID一覧
                var saleIds = sales
                    .Select(x => x.SaId)
                    .ToList();

                // 売上明細取得
                var details = context.TSaleDetails
                    .AsNoTracking()
                    .Where(
                        x => saleIds.Contains(x.SaId))
                    .Select(x => new
                    {
                        x.SaId,
                        x.SaQuantity,
                        x.SaPrTotalPrice,
                        Price = x.Pr.Price
                    })
                    .ToList();

                // 売上IDごとの金額計算
                var totalMap = details
                    .GroupBy(x => x.SaId)
                    .ToDictionary(
                        g => g.Key,
                        g => g.Sum(x =>
                            x.SaPrTotalPrice == 0
                                ? x.Price * x.SaQuantity
                                : x.SaPrTotalPrice));

                // =====================================
                // 売上履歴一覧
                // =====================================
                currentSales = sales
                    .Select(x => new SaleHistoryRow
                    {
                        SaId = x.SaId,

                        SaDate = x.SaDate,

                        ClId = x.ClId,

                        SoId = x.SoId,

                        EmId = x.EmId,

                        OrId = x.OrId,

                        Total = totalMap.TryGetValue(
                            x.SaId,
                            out decimal total)
                            ? total
                            : 0
                    })
                    .ToList();

                // =====================================
                // 月別売上集計
                // =====================================
                currentMonths = currentSales
                    .GroupBy(x => new
                    {
                        x.SaDate.Year,
                        x.SaDate.Month
                    })
                    .OrderBy(g => g.Key.Year)
                    .ThenBy(g => g.Key.Month)
                    .Select(g => new MonthlySaleRow
                    {
                        MonthText =
                            $"{g.Key.Year}年{g.Key.Month:00}月",

                        Count = g.Count(),

                        Total = g.Sum(x => x.Total)
                    })
                    .ToList();

                // =====================================
                // 画面に表示
                // =====================================
                currentPeriod = period;

                dgHistory.ItemsSource = currentSales;

                dgMonthly.ItemsSource = currentMonths;

                txtPeriod.Text = currentPeriod;

                txtCount.Text =
                    $"{currentSales.Count:N0} 件";

                txtTotal.Text =
                    $"¥{currentSales.Sum(x => x.Total):N0}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "売上履歴の取得に失敗しました。\n" +
                    ex.GetBaseException().Message,
                    "エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // =====================================
        // PDF出力
        // 元の処理を維持
        // =====================================
        private void btnPdf_Click(
            object sender,
            RoutedEventArgs e)
        {
            OpenPrintPreview();
        }

        // =====================================
        // 印刷
        // =====================================
        private void btnPrint_Click(
            object sender,
            RoutedEventArgs e)
        {
            OpenPrintPreview();
        }

        // =====================================
        // 印刷プレビュー
        // =====================================
        private void OpenPrintPreview()
        {
            if (!CheckReportData())
            {
                return;
            }

            try
            {
                FlowDocument document =
                    CreateReportDocument();

                F_SalePrintPreview preview =
                    new F_SalePrintPreview(document);

                preview.Owner = this;

                preview.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "印刷プレビューの表示に失敗しました。\n" +
                    ex.GetBaseException().Message,
                    "エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // =====================================
        // 出力データ確認
        // =====================================
        private bool CheckReportData()
        {
            if (currentSales.Count == 0)
            {
                MessageBox.Show(
                    "出力する売上データがありません。",
                    "確認",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                return false;
            }

            return true;
        }

        // =====================================
        // レポート作成
        // =====================================
        private FlowDocument CreateReportDocument()
        {
            FlowDocument document =
                new FlowDocument();

            document.FontFamily =
                new FontFamily("Yu Gothic UI");

            document.FontSize = 11;

            document.Foreground = Brushes.Black;

            // =====================================
            // タイトル
            // =====================================
            Paragraph title =
                new Paragraph(
                    new Run("売上集計報告書"));

            title.FontSize = 22;

            title.FontWeight = FontWeights.Bold;

            title.TextAlignment =
                TextAlignment.Center;

            title.Margin =
                new Thickness(0, 0, 0, 15);

            document.Blocks.Add(title);

            // =====================================
            // 基本情報
            // =====================================
            document.Blocks.Add(
                MakeParagraph("会社名：AA22"));

            document.Blocks.Add(
                MakeParagraph(
                    "対象期間：" + currentPeriod));

            document.Blocks.Add(
                MakeParagraph(
                    "出力日：" +
                    DateTime.Now.ToString(
                        "yyyy/MM/dd HH:mm")));

            document.Blocks.Add(
                MakeParagraph(
                    $"売上件数：{currentSales.Count:N0} 件"));

            decimal grandTotal =
                currentSales.Sum(x => x.Total);

            Paragraph totalParagraph =
                MakeParagraph(
                    $"売上合計：¥{grandTotal:N0}");

            totalParagraph.FontSize = 16;

            totalParagraph.FontWeight =
                FontWeights.Bold;

            document.Blocks.Add(totalParagraph);

            // =====================================
            // 月別売上集計
            // =====================================
            Paragraph monthlyTitle =
                MakeParagraph("■ 月別売上集計");

            monthlyTitle.FontSize = 15;

            monthlyTitle.FontWeight =
                FontWeights.Bold;

            monthlyTitle.Margin =
                new Thickness(0, 16, 0, 8);

            document.Blocks.Add(monthlyTitle);

            Table monthlyTable = new Table();

            monthlyTable.CellSpacing = 0;

            monthlyTable.Columns.Add(
                new TableColumn
                {
                    Width = new GridLength(170)
                });

            monthlyTable.Columns.Add(
                new TableColumn
                {
                    Width = new GridLength(100)
                });

            monthlyTable.Columns.Add(
                new TableColumn
                {
                    Width = new GridLength(180)
                });

            TableRowGroup monthlyGroup =
                new TableRowGroup();

            monthlyTable.RowGroups.Add(
                monthlyGroup);

            AddTableRow(
                monthlyGroup,
                true,
                "対象月",
                "売上件数",
                "売上金額");

            foreach (var item in currentMonths)
            {
                AddTableRow(
                    monthlyGroup,
                    false,
                    item.MonthText,
                    item.Count.ToString("N0"),
                    $"¥{item.Total:N0}");
            }

            AddTableRow(
                monthlyGroup,
                true,
                "合計",
                currentSales.Count.ToString("N0"),
                $"¥{grandTotal:N0}");

            document.Blocks.Add(monthlyTable);

            // =====================================
            // 売上履歴一覧
            // =====================================
            Paragraph historyTitle =
                MakeParagraph("■ 売上履歴一覧");

            historyTitle.FontSize = 15;

            historyTitle.FontWeight =
                FontWeights.Bold;

            historyTitle.Margin =
                new Thickness(0, 20, 0, 8);

            document.Blocks.Add(historyTitle);

            Table historyTable = new Table();

            historyTable.CellSpacing = 0;

            double[] widths =
            {
                65, 100, 70, 70, 70, 110
            };

            foreach (double width in widths)
            {
                historyTable.Columns.Add(
                    new TableColumn
                    {
                        Width = new GridLength(width)
                    });
            }

            TableRowGroup historyGroup =
                new TableRowGroup();

            historyTable.RowGroups.Add(
                historyGroup);

            AddTableRow(
                historyGroup,
                true,
                "売上ID",
                "売上日",
                "顧客ID",
                "社員ID",
                "受注ID",
                "金額");

            foreach (var sale in currentSales)
            {
                AddTableRow(
                    historyGroup,
                    false,
                    sale.SaId.ToString(),
                    sale.SaDate.ToString("yyyy/MM/dd"),
                    sale.ClId.ToString(),
                    sale.EmId.ToString(),
                    sale.OrId.ToString(),
                    $"¥{sale.Total:N0}");
            }

            document.Blocks.Add(historyTable);

            // =====================================
            // フッター
            // =====================================
            Paragraph footer =
                MakeParagraph(
                    "AA22 - 売上管理システム");

            footer.TextAlignment =
                TextAlignment.Center;

            footer.Margin =
                new Thickness(0, 20, 0, 0);

            footer.Foreground = Brushes.Gray;

            document.Blocks.Add(footer);

            return document;
        }

        // =====================================
        // 共通：Paragraph
        // =====================================
        private static Paragraph MakeParagraph(
            string value)
        {
            Paragraph paragraph =
                new Paragraph(new Run(value));

            paragraph.Margin =
                new Thickness(0, 3, 0, 3);

            return paragraph;
        }

        // =====================================
        // 共通：TableRow
        // =====================================
        private static void AddTableRow(
            TableRowGroup group,
            bool isHeader,
            params string[] values)
        {
            TableRow row = new TableRow();

            if (isHeader)
            {
                row.Background =
                    new SolidColorBrush(
                        Color.FromRgb(
                            226, 232, 240));

                row.FontWeight =
                    FontWeights.Bold;
            }

            foreach (string value in values)
            {
                TableCell cell =
                    new TableCell(
                        new Paragraph(
                            new Run(value)));

                cell.BorderBrush =
                    Brushes.LightGray;

                cell.BorderThickness =
                    new Thickness(0.5);

                cell.Padding =
                    new Thickness(5);

                row.Cells.Add(cell);
            }

            group.Rows.Add(row);
        }

        // =====================================
        // 閉じる
        // =====================================
        private void btnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            Close();
        }
    }
}
