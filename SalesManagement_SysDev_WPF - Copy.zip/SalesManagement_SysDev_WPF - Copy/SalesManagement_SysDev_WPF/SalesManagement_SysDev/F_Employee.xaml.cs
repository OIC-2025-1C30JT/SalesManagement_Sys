﻿
using System;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Employee : Window
    {
        // ========================================
        // Fields
        // ========================================
        private int? selectedEmployeeId;

        private bool isSyncingPassword;
        private bool isLoadingEmployee;
        private bool isRestoringSelection;
        private bool isSelectionChangePending = false;


        private void dgEmployee_SelectionChanged(
    object sender,
    SelectionChangedEventArgs e)
        {
            if (isRestoringSelection ||
                isLoadingEmployee ||
                isSelectionChangePending)
            {
                return;
            }

            if (dgEmployee.SelectedItem is not MEmployee newEmployee)
            {
                return;
            }

            if (selectedEmployeeId.HasValue &&
                selectedEmployeeId.Value == newEmployee.EmId)
            {
                return;
            }

            if (HasUnsavedChanges())
            {
                isSelectionChangePending = true;

                MessageBoxResult result;

                try
                {
                    result = MessageBox.Show(
                        "変更内容が保存されていません。\n" +
                        "保存せずに移動しますか？",
                        "未保存データの警告",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);
                }
                finally
                {
                    isSelectionChangePending = false;
                }

                if (result == MessageBoxResult.No)
                {
                    isRestoringSelection = true;

                    try
                    {
                        MEmployee previousEmployee = null;

                        if (selectedEmployeeId.HasValue)
                        {
                            previousEmployee = dgEmployee.Items
                                .OfType<MEmployee>()
                                .FirstOrDefault(x =>
                                    x.EmId == selectedEmployeeId.Value);
                        }

                        dgEmployee.SelectedItem = previousEmployee;

                        if (previousEmployee != null)
                        {
                            dgEmployee.ScrollIntoView(previousEmployee);
                        }
                    }
                    finally
                    {
                        isRestoringSelection = false;
                    }

                    return;
                }
            }

            LoadSelectedEmployee(newEmployee);
        }
        // Original data snapshot
        private MEmployee originalEmployee;

        // ========================================
        // Constructor
        // ========================================
        public F_Employee()
        {
            Thread.CurrentThread.CurrentCulture =
                new CultureInfo("ja-JP");

            Thread.CurrentThread.CurrentUICulture =
                new CultureInfo("ja-JP");

            InitializeComponent();

            dpHireDate.Language =
                XmlLanguage.GetLanguage("ja-JP");

            dpHireDate.SelectedDateFormat =
                DatePickerFormat.Long;
        }

        // ========================================
        // Window Loaded
        // ========================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            LoadComboData();
            LoadEmployeeData();
            Clear();
        }

        // ========================================
        // Phone Number: Digits Only
        // ========================================
        private void txtPhone_PreviewTextInput(
            object sender,
            TextCompositionEventArgs e)
        {
            e.Handled =
                !System.Text.RegularExpressions.Regex
                    .IsMatch(e.Text, @"^[0-9]+$");
        }

        private void txtPhone_Pasting(
            object sender,
            DataObjectPastingEventArgs e)
        {
            if (!e.DataObject.GetDataPresent(
                DataFormats.UnicodeText))
            {
                e.CancelCommand();
                return;
            }

            string text = e.DataObject.GetData(
                DataFormats.UnicodeText) as string ?? "";

            if (!System.Text.RegularExpressions.Regex
                .IsMatch(text, @"^[0-9]+$"))
            {
                e.CancelCommand();
            }
        }

        // ========================================
        // Load Employee Data
        // ========================================
        private void LoadEmployeeData()
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var employees = context.MEmployees
                    .AsNoTracking()
                    .Where(x => x.EmFlag == 0)
                    .OrderBy(x => x.EmId)
                    .ToList();

                dgEmployee.ItemsSource = employees;

                lblCount.Text =
                    $"表示件数：{employees.Count} 件";
            }
            catch (Exception ex)
            {
                ShowError("社員一覧取得エラー", ex);
            }
        }

        // ========================================
        // Load ComboBox Data
        // ========================================
        private void LoadComboData()
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var offices = context.MSalesOffices
                    .AsNoTracking()
                    .ToList()
                    .GroupBy(x => (x.SoName ?? "").Trim())
                    .Select(g => g
                        .OrderBy(x => x.SoId)
                        .First())
                    .OrderBy(x => x.SoName)
                    .ToList();

                cmbOffice.ItemsSource = offices;
                cmbOffice.DisplayMemberPath = "SoName";
                cmbOffice.SelectedValuePath = "SoId";

                var positions = context.MPositions
                    .AsNoTracking()
                    .Where(x => x.PoFlag == 0)
                    .ToList()
                    .GroupBy(x => (x.PoName ?? "").Trim())
                    .Select(g => g
                        .OrderBy(x => x.PoId)
                        .First())
                    .OrderBy(x => x.PoName)
                    .ToList();

                cmbPosition.ItemsSource = positions;
                cmbPosition.DisplayMemberPath = "PoName";
                cmbPosition.SelectedValuePath = "PoId";

                cmbOffice.SelectedIndex = -1;
                cmbPosition.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                ShowError("マスターデータ取得エラー", ex);
            }
        }

        // ========================================
        // Check Unsaved Changes
        // ========================================
        private bool HasUnsavedChanges()
        {
            if (isLoadingEmployee)
            {
                return false;
            }

            // New registration mode
            if (originalEmployee == null)
            {
                return
                    !string.IsNullOrWhiteSpace(txtEmID.Text) ||
                    !string.IsNullOrWhiteSpace(txtEmName.Text) ||
                    !string.IsNullOrWhiteSpace(txtPhone.Text) ||
                    cmbOffice.SelectedValue != null ||
                    cmbPosition.SelectedValue != null ||
                    dpHireDate.SelectedDate.HasValue ||
                    !string.IsNullOrEmpty(GetPassword()) ||
                    !string.IsNullOrEmpty(GetConfirmPassword());
            }

            // Existing employee edit mode
            bool changed =
                txtEmName.Text.Trim() !=
                    (originalEmployee.EmName ?? "") ||

                txtPhone.Text.Trim() !=
                    (originalEmployee.EmPhone ?? "") ||

                dpHireDate.SelectedDate !=
                    originalEmployee.EmHiredate ||

                !Equals(
                    cmbOffice.SelectedValue,
                    originalEmployee.SoId) ||

                !Equals(
                    cmbPosition.SelectedValue,
                    originalEmployee.PoId) ||

                !string.IsNullOrEmpty(GetPassword()) ||

                !string.IsNullOrEmpty(GetConfirmPassword());

            return changed;
        }

        // ========================================
        // Unsaved Changes Warning
        // ========================================
        private bool ConfirmDiscardChanges()
        {
            if (!HasUnsavedChanges())
            {
                return true;
            }

            MessageBoxResult result = MessageBox.Show(
                "変更内容が保存されていません。\n" +
                "保存せずに移動しますか？",
                "未保存データの警告",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            return result == MessageBoxResult.Yes;
        }

        // ========================================
        // DataGrid Selection Changed
        // ========================================
     
        // ========================================
        // Display Selected Employee
        // ========================================
        private void LoadSelectedEmployee(
            MEmployee employee)
        {
            isLoadingEmployee = true;

            try
            {
                selectedEmployeeId = employee.EmId;

                // Snapshot for change detection
                originalEmployee = new MEmployee
                {
                    EmId = employee.EmId,
                    EmName = employee.EmName,
                    EmPhone = employee.EmPhone,
                    EmHiredate = employee.EmHiredate,
                    SoId = employee.SoId,
                    PoId = employee.PoId,
                    EmFlag = employee.EmFlag
                };

                txtEmID.Text =
                    employee.EmId.ToString();

                txtEmID.IsReadOnly = true;
                txtEmID.Background =
                    Brushes.LightGray;

                txtEmName.Text =
                    employee.EmName ?? "";

                txtPhone.Text =
                    employee.EmPhone ?? "";

                dpHireDate.SelectedDate =
                    employee.EmHiredate;

                cmbOffice.SelectedValue =
                    employee.SoId;

                cmbPosition.SelectedValue =
                    employee.PoId;

                // Do not display saved password
                ClearPasswordFields();

                btnInsert.IsEnabled = false;
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            finally
            {
                isLoadingEmployee = false;
            }
        }

        // ========================================
        // Password Synchronization
        // ========================================
        private void txtPassword_PasswordChanged(
            object sender,
            RoutedEventArgs e)
        {
            if (isSyncingPassword)
            {
                return;
            }

            isSyncingPassword = true;

            try
            {
                txtPasswordVisible.Text =
                    txtPassword.Password;
            }
            finally
            {
                isSyncingPassword = false;
            }
        }

        private void txtPasswordVisible_TextChanged(
            object sender,
            TextChangedEventArgs e)
        {
            if (isSyncingPassword)
            {
                return;
            }

            isSyncingPassword = true;

            try
            {
                txtPassword.Password =
                    txtPasswordVisible.Text;
            }
            finally
            {
                isSyncingPassword = false;
            }
        }

        private void txtPasswordConfirm_PasswordChanged(
            object sender,
            RoutedEventArgs e)
        {
            if (isSyncingPassword)
            {
                return;
            }

            isSyncingPassword = true;

            try
            {
                txtPasswordConfirmVisible.Text =
                    txtPasswordConfirm.Password;
            }
            finally
            {
                isSyncingPassword = false;
            }
        }

        private void txtPasswordConfirmVisible_TextChanged(
            object sender,
            TextChangedEventArgs e)
        {
            if (isSyncingPassword)
            {
                return;
            }

            isSyncingPassword = true;

            try
            {
                txtPasswordConfirm.Password =
                    txtPasswordConfirmVisible.Text;
            }
            finally
            {
                isSyncingPassword = false;
            }
        }

        // ========================================
        // Show / Hide Password
        // ========================================
        private void chkShowPassword_Changed(
            object sender,
            RoutedEventArgs e)
        {
            bool show =
                chkShowPassword.IsChecked == true;

            if (show)
            {
                txtPasswordVisible.Text =
                    txtPassword.Password;

                txtPasswordConfirmVisible.Text =
                    txtPasswordConfirm.Password;

                txtPassword.Visibility =
                    Visibility.Collapsed;

                txtPasswordConfirm.Visibility =
                    Visibility.Collapsed;

                txtPasswordVisible.Visibility =
                    Visibility.Visible;

                txtPasswordConfirmVisible.Visibility =
                    Visibility.Visible;
            }
            else
            {
                txtPassword.Password =
                    txtPasswordVisible.Text;

                txtPasswordConfirm.Password =
                    txtPasswordConfirmVisible.Text;

                txtPasswordVisible.Visibility =
                    Visibility.Collapsed;

                txtPasswordConfirmVisible.Visibility =
                    Visibility.Collapsed;

                txtPassword.Visibility =
                    Visibility.Visible;

                txtPasswordConfirm.Visibility =
                    Visibility.Visible;
            }
        }

        // ========================================
        // Get Password
        // ========================================
        private string GetPassword()
        {
            return chkShowPassword.IsChecked == true
                ? txtPasswordVisible.Text
                : txtPassword.Password;
        }

        private string GetConfirmPassword()
        {
            return chkShowPassword.IsChecked == true
                ? txtPasswordConfirmVisible.Text
                : txtPasswordConfirm.Password;
        }

        // ========================================
        // Clear Password
        // ========================================
        private void ClearPasswordFields()
        {
            isSyncingPassword = true;

            try
            {
                txtPassword.Clear();
                txtPasswordConfirm.Clear();

                txtPasswordVisible.Clear();
                txtPasswordConfirmVisible.Clear();
            }
            finally
            {
                isSyncingPassword = false;
            }

            chkShowPassword.IsChecked = false;

            txtPassword.Visibility =
                Visibility.Visible;

            txtPasswordConfirm.Visibility =
                Visibility.Visible;

            txtPasswordVisible.Visibility =
                Visibility.Collapsed;

            txtPasswordConfirmVisible.Visibility =
                Visibility.Collapsed;
        }

        // ========================================
        // Validate Input
        // ========================================
        private bool ValidateInput(
            out int employeeId,
            bool isInsert)
        {
            employeeId = 0;

            if (!int.TryParse(
                txtEmID.Text.Trim(),
                out employeeId) || employeeId <= 0)
            {
                MessageBox.Show(
                    "社員IDは1以上の数字で入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                txtEmName.Text))
            {
                MessageBox.Show(
                    "社員名を入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            if (cmbOffice.SelectedValue == null)
            {
                MessageBox.Show(
                    "営業所を選択してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            if (cmbPosition.SelectedValue == null)
            {
                MessageBox.Show(
                    "役職を選択してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            string password = GetPassword();
            string confirm = GetConfirmPassword();

            // Registration: Password required
            if (isInsert &&
                string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show(
                    "パスワードを入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            // Update: Both empty means no password change
            if (!isInsert &&
                string.IsNullOrEmpty(password) &&
                string.IsNullOrEmpty(confirm))
            {
                return true;
            }

            if (string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(confirm))
            {
                MessageBox.Show(
                    "パスワードと確認用パスワードを入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            if (password != confirm)
            {
                MessageBox.Show(
                    "パスワードが一致しません。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            return true;
        }

        // ========================================
        // Insert Employee
        // ========================================
        private void btnInsert_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (selectedEmployeeId.HasValue)
            {
                MessageBox.Show(
                    "新規登録する場合はクリアしてください。");
                return;
            }

            if (!ValidateInput(
                out int employeeId,
                true))
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                bool exists = context.MEmployees
                    .Any(x => x.EmId == employeeId);

                if (exists)
                {
                    MessageBox.Show(
                        "この社員IDは既に登録されています。",
                        "重複エラー",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                var employee = new MEmployee
                {
                    EmId = employeeId,
                    EmName = txtEmName.Text.Trim(),
                    EmPassword = GetPassword(),
                    EmPhone = txtPhone.Text.Trim(),
                    EmHiredate =
                        dpHireDate.SelectedDate ?? DateTime.Today,
                    SoId = (int)cmbOffice.SelectedValue,
                    PoId = (int)cmbPosition.SelectedValue,
                    EmFlag = 0
                };

                context.MEmployees.Add(employee);
                context.SaveChanges();

                MessageBox.Show(
                    "社員登録が完了しました。",
                    "登録完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                Clear();
                LoadEmployeeData();
            }
            catch (Exception ex)
            {
                ShowError("社員登録エラー", ex);
            }
        }

        // ========================================
        // Update Employee
        // ========================================
        private void btnUpdate_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedEmployeeId.HasValue)
            {
                MessageBox.Show(
                    "更新する社員を選択してください。");
                return;
            }

            if (!ValidateInput(
                out int id,
                false))
            {
                return;
            }

            if (id != selectedEmployeeId.Value)
            {
                MessageBox.Show(
                    "社員IDが一致しません。");
                return;
            }

            if (MessageBox.Show(
                "社員情報を更新しますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                var employee = context.MEmployees
                    .FirstOrDefault(x =>
                        x.EmId == id &&
                        x.EmFlag == 0);

                if (employee == null)
                {
                    MessageBox.Show(
                        "社員が見つかりません。");
                    return;
                }

                employee.EmName =
                    txtEmName.Text.Trim();

                employee.EmPhone =
                    txtPhone.Text.Trim();

                employee.EmHiredate =
                    dpHireDate.SelectedDate ?? DateTime.Today;

                employee.SoId =
                    (int)cmbOffice.SelectedValue;

                employee.PoId =
                    (int)cmbPosition.SelectedValue;

                string newPassword = GetPassword();

                // Change password only when entered
                if (!string.IsNullOrEmpty(newPassword))
                {
                    employee.EmPassword = newPassword;
                }

                context.SaveChanges();

                MessageBox.Show(
                    "社員更新が完了しました。",
                    "更新完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                Clear();
                LoadEmployeeData();
            }
            catch (Exception ex)
            {
                ShowError("社員更新エラー", ex);
            }
        }

        // ========================================
        // Hide Employee
        // ========================================
        private void btnDelete_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedEmployeeId.HasValue)
            {
                MessageBox.Show(
                    "非表示にする社員を選択してください。");
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                return;
            }

            int id = selectedEmployeeId.Value;

            if (MessageBox.Show(
                "この社員を非表示にしますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                var employee = context.MEmployees
                    .FirstOrDefault(x =>
                        x.EmId == id &&
                        x.EmFlag == 0);

                if (employee == null)
                {
                    MessageBox.Show(
                        "社員が見つかりません。");
                    return;
                }

                employee.EmFlag = 2;
                context.SaveChanges();

                MessageBox.Show(
                    "社員を非表示にしました。",
                    "完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                Clear();
                LoadEmployeeData();
            }
            catch (Exception ex)
            {
                ShowError("非表示エラー", ex);
            }
        }

        // ========================================
        // Show All
        // ========================================
        private void btnShowAll_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            Clear();
            LoadEmployeeData();
        }

        // ========================================
        // Clear Button
        // ========================================
        private void btnClear_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            Clear();
        }

        // ========================================
        // Clear Form
        // ========================================
        private void Clear()
        {
            isLoadingEmployee = true;

            try
            {
                dgEmployee.SelectedItem = null;

                selectedEmployeeId = null;
                originalEmployee = null;

                txtEmID.Clear();
                txtEmName.Clear();
                txtPhone.Clear();

                ClearPasswordFields();

                dpHireDate.SelectedDate = null;

                cmbOffice.SelectedIndex = -1;
                cmbPosition.SelectedIndex = -1;

                txtEmID.IsReadOnly = false;
                txtEmID.Background = Brushes.White;

                btnInsert.IsEnabled = true;
                btnUpdate.IsEnabled = false;
                btnDelete.IsEnabled = false;
            }
            finally
            {
                isLoadingEmployee = false;
            }
        }

        // ========================================
        // Close Window
        // ========================================
        private void btnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "社員管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Close();
            }
        }

        // ========================================
        // Error Message
        // ========================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                ex.GetBaseException().Message,
                title,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
