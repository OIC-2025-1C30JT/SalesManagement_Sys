﻿
using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Stock : Window
    {
        public F_Stock()
        {
            InitializeComponent();
        }

        // 画面起動時
        private void Window_Loaded(
            object sender, RoutedEventArgs e)
        {
            LoadStockData();
        }

        // 在庫一覧表示
        private void LoadStockData(string keyword = "")
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query = context.TStocks
                    .AsNoTracking()
                    .Where(x => x.StFlag == 0);

                // 商品名検索
                if (!string.IsNullOrWhiteSpace(keyword))
                {
                    query = query.Where(x =>
                        x.Pr.PrName.Contains(keyword));
                }

                var data = query
                    .Select(x => new
                    {
                        StockId = x.StId,
                        ProductId = x.PrId,
                        ProductName = x.Pr.PrName,
                        StockQuantity = x.StQuantity
                    })
                    .OrderBy(x => x.ProductId)
                    .ToList();

                // 在庫状態を追加
                var stockList = data.Select(x => new
                {
                    x.StockId,
                    x.ProductId,
                    x.ProductName,
                    x.StockQuantity,
                    StockStatus = x.StockQuantity <= 0
                        ? "在庫なし"
                        : "在庫あり"
                }).ToList();

                dgStock.ItemsSource = stockList;

                txtCount.Text = stockList.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "在庫一覧取得エラー:\n" +
                    ex.GetBaseException().Message,
                    "エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // 検索
        private void BtnSearch_Click(
            object sender, RoutedEventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            LoadStockData(keyword);
        }

        // 一覧表示
        private void BtnList_Click(
            object sender, RoutedEventArgs e)
        {
            txtSearch.Clear();
            LoadStockData();
        }

        // 閉じる
       
        private void BtnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "在庫管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Close();
            }
        }

    }
}
