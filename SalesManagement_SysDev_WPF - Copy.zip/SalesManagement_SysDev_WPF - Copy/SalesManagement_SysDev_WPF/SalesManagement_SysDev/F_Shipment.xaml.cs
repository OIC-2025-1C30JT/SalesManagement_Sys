﻿
using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Shipment : Window
    {
        private readonly int? _employeeId;

        public F_Shipment(int? employeeId = null)
        {
            InitializeComponent();
            _employeeId = employeeId;
        }

        // 画面起動時
        private void Window_Loaded(
            object sender, RoutedEventArgs e)
        {
            LoadSyukkoData();
        }

        // 出庫一覧表示
        private void LoadSyukkoData(string keyword = "")
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query =
                    from syukko in context.TSyukkos.AsNoTracking()
                    join detail in context.TSyukkoDetails.AsNoTracking()
                        on syukko.SyId equals detail.SyId
                    join product in context.MProducts.AsNoTracking()
                        on detail.PrId equals product.PrId
                    where syukko.SyFlag == 0
                    select new
                    {
                        syukko.SyId,
                        syukko.OrId,
                        syukko.ClId,
                        detail.PrId,
                        PrName = product.PrName,
                        detail.SyQuantity,
                        syukko.SyStateFlag
                    };

                if (!string.IsNullOrWhiteSpace(keyword))
                {
                    query = query.Where(x =>
                        x.PrName.Contains(keyword));
                }

                dgShipment.ItemsSource = query
                    .OrderByDescending(x => x.SyId)
                    .ToList();
            }
            catch (Exception ex)
            {
                ShowError("出庫一覧取得エラー", ex);
            }
        }

        // 出庫確定
        private void btnConfirm_Click(
            object sender, RoutedEventArgs e)
        {
            if (dgShipment.SelectedItem == null)
            {
                MessageBox.Show(
                    "出庫データを選択してください。");
                return;
            }

            if (!_employeeId.HasValue)
            {
                MessageBox.Show(
                    "担当社員IDが設定されていません。\n" +
                    "ログイン中の社員IDを確認してください。");
                return;
            }

            // 選択行の出庫IDを取得
            int syId;

            try
            {
                var selected = dgShipment.SelectedItem;

                var property = selected.GetType()
                    .GetProperty("SyId");

                if (property == null)
                {
                    MessageBox.Show(
                        "出庫IDを取得できません。");
                    return;
                }

                syId = Convert.ToInt32(
                    property.GetValue(selected));
            }
            catch (Exception ex)
            {
                ShowError("出庫ID取得エラー", ex);
                return;
            }

            var answer = MessageBox.Show(
                $"出庫ID {syId} を確定しますか？",
                "出庫確定",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (answer != MessageBoxResult.Yes)
                return;

            try
            {
                using var context =
                    new SalesManagementContext();

                using var transaction =
                    context.Database.BeginTransaction(
                        System.Data.IsolationLevel.Serializable);

                // 出庫情報と詳細を取得
                var syukko = context.TSyukkos
                    .Include(s => s.TSyukkoDetails)
                    .FirstOrDefault(s =>
                        s.SyId == syId &&
                        s.SyFlag == 0);

                if (syukko == null)
                {
                    MessageBox.Show(
                        "出庫データが見つかりません。");
                    return;
                }

                // 二重確定防止
                if (syukko.SyStateFlag != 0)
                {
                    MessageBox.Show(
                        "この出庫データは既に確定済みです。");
                    return;
                }

                var details =
                    syukko.TSyukkoDetails.ToList();

                if (details.Count == 0)
                {
                    MessageBox.Show(
                        "出庫詳細データがありません。");
                    return;
                }

                if (details.Any(d => d.SyQuantity <= 0))
                {
                    MessageBox.Show(
                        "出庫数量が正しくありません。");
                    return;
                }

                // 同じ受注IDの入荷データがないか確認
                if (context.TArrivals.Any(a =>
                    a.OrId == syukko.OrId))
                {
                    MessageBox.Show(
                        "この受注の入荷データは既に存在します。");
                    return;
                }

                // 入荷データ作成
                var arrival = new TArrival
                {
                    OrId = syukko.OrId,
                    ClId = syukko.ClId,
                    SoId = syukko.SoId,
                    EmId = null,
                    ArDate = null,
                    ArStateFlag = 0,
                    ArFlag = 0
                };

                // 入荷詳細データ作成
                foreach (var detail in details)
                {
                    arrival.TArrivalDetails.Add(
                        new TArrivalDetail
                        {
                            PrId = detail.PrId,
                            ArQuantity = detail.SyQuantity
                        });
                }

                context.TArrivals.Add(arrival);

                // 出庫確定
                syukko.SyStateFlag = 1;
                syukko.SyDate = DateTime.Now;
                syukko.EmId = _employeeId.Value;

                context.SaveChanges();
                transaction.Commit();

                MessageBox.Show(
                    "出庫確定が完了しました。\n" +
                    "入荷ID: " + arrival.ArId,
                    "完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                LoadSyukkoData();
            }
            catch (Exception ex)
            {
                ShowError("出庫確定エラー", ex);
            }
        }

        // 商品名検索
        private void btnSearch_Click(
            object sender, RoutedEventArgs e)
        {
            LoadSyukkoData(txtSearch.Text.Trim());
        }

        // 一覧表示
        private void btnList_Click(
            object sender, RoutedEventArgs e)
        {
            txtSearch.Clear();
            LoadSyukkoData();
        }

        // 閉じる

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "出庫管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }


        // エラー表示
        private void ShowError(
            string title, Exception ex)
        {
            MessageBox.Show(
                title + ":\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
