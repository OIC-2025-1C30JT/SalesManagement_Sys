﻿
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Sale : Window
    {
        public F_Sale()
        {
            InitializeComponent();
        }

        // 売上詳細表示用
        private class SaleDetailRow
        {
            public int PrId { get; set; }

            public string ProductName { get; set; } = "";

            public int Quantity { get; set; }

            public decimal UnitPrice { get; set; }

            public decimal Amount { get; set; }
        }

        // =====================================
        // 画面起動
        // =====================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            LoadSaleData();
        }

        // =====================================
        // 売上一覧表示
        // =====================================

        private void LoadSaleData(
            int? saleId = null,
            int? clientId = null,
            DateTime? saleDate = null)
        {
            try
            {
                using var context = new SalesManagementContext();

                var query = context.TSales
                    .AsNoTracking()
                    .AsQueryable();

                // 通常表示の売上のみ
                query = query.Where(x => x.SaFlag == 0);

                // 売上ID検索
                if (saleId.HasValue)
                {
                    query = query.Where(
                        x => x.SaId == saleId.Value);
                }

                // 顧客ID検索
                if (clientId.HasValue)
                {
                    query = query.Where(
                        x => x.ClId == clientId.Value);
                }

                // 売上日検索
                if (saleDate.HasValue)
                {
                    DateTime start = saleDate.Value.Date;
                    DateTime end = start.AddDays(1);

                    query = query.Where(
                        x => x.SaDate >= start &&
                             x.SaDate < end);
                }

                var sales = query
                    .OrderByDescending(x => x.SaId)
                    .ToList();

                dgSale.ItemsSource = sales;

                ClearSaleDetail();
            }
            catch (Exception ex)
            {
                ShowError("売上一覧取得エラー", ex);
            }
        }

        // =====================================
        // 検索
        // =====================================


        private void btnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            int? saleId = null;
            int? clientId = null;

            string saleText = txtSaleId.Text.Trim();
            string clientText = txtSearch.Text.Trim();

            // 売上ID
            if (!string.IsNullOrWhiteSpace(saleText))
            {
                if (!int.TryParse(saleText, out int id))
                {
                    MessageBox.Show(
                        "売上IDは数字で入力してください。",
                        "入力エラー",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    txtSaleId.Focus();
                    return;
                }

                saleId = id;
            }

            // 顧客ID
            if (!string.IsNullOrWhiteSpace(clientText))
            {
                if (!int.TryParse(clientText, out int id))
                {
                    MessageBox.Show(
                        "顧客IDは数字で入力してください。",
                        "入力エラー",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    txtSearch.Focus();
                    return;
                }

                clientId = id;
            }

            LoadSaleData(
                saleId,
                clientId,
                dpSearchDate.SelectedDate);

            if (dgSale.Items.Count == 0)
            {
                MessageBox.Show(
                    "該当する売上データがありません。",
                    "検索結果",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        // =====================================
        // 一覧表示
        // =====================================
        private void btnReload_Click(
            object sender,
            RoutedEventArgs e)
        {
            txtSaleId.Clear();
            txtSearch.Clear();

            dpSearchDate.SelectedDate = null;

            LoadSaleData();
        }

        // =====================================
        // 売上選択
        // =====================================
        private void dgSale_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (dgSale.SelectedItem is TSale sale)
            {
                LoadSaleDetail(sale.SaId);
            }
            else
            {
                ClearSaleDetail();
            }
        }

        // =====================================
        // 売上詳細表示
        // =====================================

        private void LoadSaleDetail(int saleId)
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var details = context.TSaleDetails
                    .AsNoTracking()
                    .Where(x => x.SaId == saleId)
                    .Select(x => new SaleDetailRow
                    {
                        PrId = x.PrId,

                        ProductName = x.Pr.PrName,

                        Quantity = x.SaQuantity,

                        UnitPrice = x.Pr.Price,

                        // 金額計算
                        Amount = x.SaPrTotalPrice == 0
                            ? x.Pr.Price * x.SaQuantity
                            : x.SaPrTotalPrice
                    })
                    .ToList();

                dgSaleDetail.ItemsSource = details;

                // 合計金額
                decimal total = details.Sum(x => x.Amount);

                txtSelectedSale.Text =
                    $"売上ID: {saleId}";

                txtTotalAmount.Text =
                    $"¥{total:N0}";

                if (details.Count == 0)
                {
                    txtSelectedSale.Text =
                        $"売上ID: {saleId}（詳細なし）";
                }
            }
            catch (Exception ex)
            {
                ClearSaleDetail();

                ShowError("売上詳細取得エラー", ex);
            }
        }
        // 閉じる
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "売上管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }


        // =====================================
        // 詳細クリア
        // =====================================
        private void ClearSaleDetail()
        {
            dgSaleDetail.ItemsSource = null;

            txtSelectedSale.Text =
                "売上を選択してください";

            txtTotalAmount.Text = "¥0";
        }

        // =====================================


        private void btnHistory_Click(
            object sender,
            RoutedEventArgs e)
        {
            F_SaleHistory history = new F_SaleHistory();

            history.Owner = this;

            history.ShowDialog();
        }

        // =====================================


        // =====================================
        // エラー表示
        // =====================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                title + ":\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
