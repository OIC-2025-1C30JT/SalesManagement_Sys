﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Client : Window
    {
        // =====================================
        // Fields
        // =====================================
        private int? selectedClientId;

        private bool isLoadingClient;
        private bool isRestoringSelection;
        private bool isSelectionChangePending;
        private bool allowClose;

        private MClient originalClient;

        // =====================================
        // Constructor
        // =====================================
        public F_Client()
        {
            InitializeComponent();
        }

        // =====================================
        // Window Loaded
        // =====================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            ClearInputFields();
            LoadClientData();
        }

        // =====================================
        // Load Client Data
        // =====================================
        private void LoadClientData()
        {
            try
            {
                isLoadingClient = true;

                using var context =
                    new SalesManagementContext();

                IQueryable<MClient> query =
                    context.MClients.AsNoTracking();

                if (chkShowHidden.IsChecked != true)
                {
                    query = query.Where(x => x.ClFlag == 0);
                }

                List<MClient> clients = query
                    .OrderBy(x => x.ClId)
                    .ToList();

                dgClient.ItemsSource = clients;

                lblCount.Text =
                    $"表示件数：{clients.Count} 件";
            }
            catch (Exception ex)
            {
                ShowError("一覧表示エラー", ex);
            }
            finally
            {
                isLoadingClient = false;
            }
        }

        // =====================================
        // Check Unsaved Changes
        // =====================================
        private bool HasUnsavedChanges()
        {
            if (isLoadingClient)
            {
                return false;
            }

            // New registration mode
            if (originalClient == null)
            {
                return
                    !string.IsNullOrWhiteSpace(txtClID.Text) ||
                    !string.IsNullOrWhiteSpace(txtClName.Text) ||
                    !string.IsNullOrWhiteSpace(txtPostal.Text) ||
                    !string.IsNullOrWhiteSpace(txtPhone.Text) ||
                    !string.IsNullOrWhiteSpace(txtAddress.Text);
            }

            // Update mode
            return
                txtClName.Text.Trim() !=
                    (originalClient.ClName ?? "") ||

                txtPostal.Text.Trim() !=
                    (originalClient.ClPostal ?? "") ||

                txtPhone.Text.Trim() !=
                    (originalClient.ClPhone ?? "") ||

                txtAddress.Text.Trim() !=
                    (originalClient.ClAddress ?? "");
        }

        // =====================================
        // Unsaved Warning
        // =====================================
        private bool ConfirmDiscardChanges()
        {
            if (!HasUnsavedChanges())
            {
                return true;
            }

            MessageBoxResult result = MessageBox.Show(
                "変更内容が保存されていません。\n" +
                "保存せずに移動しますか？",
                "未保存データの警告",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            return result == MessageBoxResult.Yes;
        }

        // =====================================
        // DataGrid Selection Changed
        // =====================================
        private void dgClient_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (isRestoringSelection ||
                isLoadingClient ||
                isSelectionChangePending)
            {
                return;
            }

            if (dgClient.SelectedItem is not MClient newClient)
            {
                return;
            }

            if (selectedClientId.HasValue &&
                selectedClientId.Value == newClient.ClId)
            {
                return;
            }

            if (HasUnsavedChanges())
            {
                isSelectionChangePending = true;

                MessageBoxResult result;

                try
                {
                    result = MessageBox.Show(
                        "変更内容が保存されていません。\n" +
                        "保存せずに移動しますか？",
                        "未保存データの警告",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);
                }
                finally
                {
                    isSelectionChangePending = false;
                }

                if (result == MessageBoxResult.No)
                {
                    isRestoringSelection = true;

                    try
                    {
                        MClient previousClient = null;

                        if (selectedClientId.HasValue)
                        {
                            previousClient = dgClient.Items
                                .OfType<MClient>()
                                .FirstOrDefault(x =>
                                    x.ClId ==
                                    selectedClientId.Value);
                        }

                        dgClient.SelectedItem =
                            previousClient;

                        if (previousClient != null)
                        {
                            dgClient.ScrollIntoView(
                                previousClient);
                        }
                    }
                    finally
                    {
                        isRestoringSelection = false;
                    }

                    return;
                }
            }

            LoadSelectedClient(newClient);
        }

        // =====================================
        // Display Selected Client
        // =====================================
        private void LoadSelectedClient(
            MClient client)
        {
            isLoadingClient = true;

            try
            {
                selectedClientId = client.ClId;

                // Snapshot
                originalClient = new MClient
                {
                    ClId = client.ClId,
                    ClName = client.ClName,
                    ClAddress = client.ClAddress,
                    ClPhone = client.ClPhone,
                    ClPostal = client.ClPostal,
                    ClFlag = client.ClFlag,
                    SoId = client.SoId
                };

                txtClID.Text =
                    client.ClId.ToString();

                txtClID.IsReadOnly = true;
                txtClID.Background =
                    Brushes.LightGray;

                txtClName.Text =
                    client.ClName ?? "";

                txtAddress.Text =
                    client.ClAddress ?? "";

                txtPhone.Text =
                    client.ClPhone ?? "";

                txtPostal.Text =
                    client.ClPostal ?? "";

                btnInsert.IsEnabled = false;
                btnUpdate.IsEnabled =
                    client.ClFlag == 0;
                btnDelete.IsEnabled =
                    client.ClFlag == 0;
            }
            finally
            {
                isLoadingClient = false;
            }
        }

        // =====================================
        // Validate Input
        // =====================================
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(
                txtClName.Text))
            {
                MessageBox.Show(
                    "顧客名を入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtClName.Focus();
                return false;
            }

            if (!string.IsNullOrWhiteSpace(txtClID.Text) &&
                (!int.TryParse(txtClID.Text, out int id) ||
                 id <= 0))
            {
                MessageBox.Show(
                    "顧客IDは正しい数字で入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        // =====================================
        // Insert
        // =====================================
        private void btnInsert_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (selectedClientId.HasValue)
            {
                MessageBox.Show(
                    "新規登録する場合はクリアしてください。");
                return;
            }

            if (!ValidateInput())
            {
                return;
            }

            if (MessageBox.Show(
                "新しい顧客を登録しますか？",
                "登録確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                var client = new MClient
                {
                    ClName = txtClName.Text.Trim(),
                    ClAddress = txtAddress.Text.Trim(),
                    ClPhone = txtPhone.Text.Trim(),
                    ClPostal = txtPostal.Text.Trim(),
                    ClFax = "",
                    ClFlag = 0,
                    SoId = 1
                };

                // Auto-generated ID if blank
                if (!string.IsNullOrWhiteSpace(txtClID.Text))
                {
                    int id = int.Parse(txtClID.Text);

                    if (context.MClients
                        .Any(x => x.ClId == id))
                    {
                        MessageBox.Show(
                            "この顧客IDは既に登録されています。",
                            "重複エラー",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                        return;
                    }

                    client.ClId = id;
                }

                context.MClients.Add(client);
                context.SaveChanges();

                ClearInputFields();
                LoadClientData();

                MessageBox.Show(
                    "顧客を登録しました。",
                    "登録完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("登録エラー", ex);
            }
        }

        // =====================================
        // Update
        // =====================================
        private void btnUpdate_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedClientId.HasValue)
            {
                MessageBox.Show(
                    "更新する顧客を選択してください。");
                return;
            }

            if (!ValidateInput())
            {
                return;
            }

            if (MessageBox.Show(
                "選択した顧客情報を更新しますか？",
                "更新確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                MClient client = context.MClients
                    .FirstOrDefault(x =>
                        x.ClId == selectedClientId.Value &&
                        x.ClFlag == 0);

                if (client == null)
                {
                    MessageBox.Show(
                        "顧客が見つかりません。");
                    return;
                }

                client.ClName =
                    txtClName.Text.Trim();

                client.ClAddress =
                    txtAddress.Text.Trim();

                client.ClPhone =
                    txtPhone.Text.Trim();

                client.ClPostal =
                    txtPostal.Text.Trim();

                context.SaveChanges();

                ClearInputFields();
                LoadClientData();

                MessageBox.Show(
                    "顧客情報を更新しました。",
                    "更新完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("更新エラー", ex);
            }
        }

        // =====================================
        // Hide Client
        // =====================================
        private void btnDelete_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedClientId.HasValue)
            {
                MessageBox.Show(
                    "非表示にする顧客を選択してください。");
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                return;
            }

            if (MessageBox.Show(
                "選択した顧客を非表示にしますか？",
                "非表示確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                MClient client = context.MClients
                    .FirstOrDefault(x =>
                        x.ClId == selectedClientId.Value &&
                        x.ClFlag == 0);

                if (client == null)
                {
                    MessageBox.Show(
                        "顧客が見つかりません。");
                    return;
                }

                client.ClFlag = 2;
                context.SaveChanges();

                ClearInputFields();
                LoadClientData();

                MessageBox.Show(
                    "顧客を非表示にしました。",
                    "非表示完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("非表示エラー", ex);
            }
        }

        // =====================================
        // Clear
        // =====================================
        private void btnClear_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            ClearInputFields();
        }

        private void ClearInputFields()
        {
            isLoadingClient = true;

            try
            {
                dgClient.SelectedItem = null;

                selectedClientId = null;
                originalClient = null;

                txtClID.Clear();
                txtClName.Clear();
                txtAddress.Clear();
                txtPhone.Clear();
                txtPostal.Clear();

                txtClID.IsReadOnly = false;
                txtClID.Background = Brushes.White;

                btnInsert.IsEnabled = true;
                btnUpdate.IsEnabled = false;
                btnDelete.IsEnabled = false;

                txtClID.Focus();
            }
            finally
            {
                isLoadingClient = false;
            }
        }

        // =====================================
        // Show All
        // =====================================
        private void btnShowAll_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            ClearInputFields();
            LoadClientData();
        }

        // =====================================
        // Show Hidden Clients
        // =====================================
        private void chkShowHidden_Changed(
            object sender,
            RoutedEventArgs e)
        {
            if (!IsLoaded)
            {
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                isLoadingClient = true;

                try
                {
                    chkShowHidden.IsChecked =
                        !chkShowHidden.IsChecked;
                }
                finally
                {
                    isLoadingClient = false;
                }

                return;
            }

            ClearInputFields();
            LoadClientData();
        }

        // =====================================
        // ID Digits Only
        // =====================================
        private void Id_PreviewTextInput(
            object sender,
            TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(
                c => c >= '0' && c <= '9');
        }

        // =====================================
        // Phone Digits Only
        // =====================================
        private void Phone_PreviewTextInput(
            object sender,
            TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(
                c => c >= '0' && c <= '9');
        }

        // =====================================
        // Paste Check
        // =====================================
        private void Phone_Pasting(
            object sender,
            DataObjectPastingEventArgs e)
        {
            if (!e.DataObject.GetDataPresent(
                DataFormats.UnicodeText))
            {
                e.CancelCommand();
                return;
            }

            string text = e.DataObject.GetData(
                DataFormats.UnicodeText) as string;

            if (string.IsNullOrEmpty(text) ||
                !text.All(c => c >= '0' && c <= '9'))
            {
                e.CancelCommand();
            }
        }

        // =====================================
        // Closing
        // =====================================
        private void btnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Closing(
            object sender,
            CancelEventArgs e)
        {
            if (allowClose)
            {
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                e.Cancel = true;
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "顧客管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
            {
                e.Cancel = true;
                return;
            }

            allowClose = true;
        }

        // =====================================
        // Error
        // =====================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                ex.GetBaseException().Message,
                title,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
