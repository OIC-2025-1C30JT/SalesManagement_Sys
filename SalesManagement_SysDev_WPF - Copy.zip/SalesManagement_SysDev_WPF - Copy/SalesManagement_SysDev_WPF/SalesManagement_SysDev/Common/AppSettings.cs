﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace SalesManagement_SysDev
{
    // settings.json に保存する内容
    public class SettingsData
    {
        public string CompanyName { get; set; } = "";

        // 身分名 → 使用できるモジュール Key の一覧
        public Dictionary<string, List<string>> RolePermissions { get; set; } = new Dictionary<string, List<string>>();

        // 社員ID → その社員だけの個別設定（あれば身分の設定より優先される）
        public Dictionary<int, List<string>> EmployeePermissions { get; set; } = new Dictionary<int, List<string>>();

        // リーダーの社員ID（ここに無い社員は一般社員）
        public List<int> LeaderEmployeeIds { get; set; } = new List<int>();
    }

    // 設定ファイル（settings.json）の読み書き
    public static class AppSettings
    {
        private const string DefaultCompany = "株式会社サンプル";

        // 保存先：C:\Users\（ユーザー名）\AppData\Roaming\SalesManagement_SysDev\settings.json
        // ※実行ファイルのフォルダ（bin）に置くと、リビルド・クリーンで消えてしまうため、ここにしている
        private static string filePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "SalesManagement_SysDev",
            "settings.json");

        private static SettingsData? data = null;

        // 保存先のパス（画面に表示する用）
        public static string FilePath
        {
            get { return filePath; }
        }

        private static SettingsData Data
        {
            get
            {
                if (data == null)
                {
                    Load();
                }
                if (data == null)
                {
                    data = CreateDefault();
                }
                return data;
            }
        }

        // 初期設定（物流担当と営業担当の使えるモジュール）
        private static SettingsData CreateDefault()
        {
            SettingsData d = new SettingsData();
            d.CompanyName = DefaultCompany;
            d.RolePermissions[LoginSession.RoleLogistics] = new List<string>
            {
                ModulePermission.Product, ModulePermission.Stock, ModulePermission.Syukko,
                ModulePermission.Hattyu, ModulePermission.Warehousing
            };
            d.RolePermissions[LoginSession.RoleSales] = new List<string>
            {
                ModulePermission.Client, ModulePermission.Order, ModulePermission.Chumon,
                ModulePermission.Arrival, ModulePermission.Shipment, ModulePermission.Sale
            };
            return d;
        }

        // ファイルを読み込む（無い・壊れている場合は初期設定を使う）
        public static void Load()
        {
            SettingsData? loaded = null;

            try
            {
                string readPath = filePath;

                // 旧バージョンの保存場所（実行ファイルと同じフォルダ）にだけファイルがある場合は、それを引き継ぐ
                if (!File.Exists(readPath))
                {
                    string oldPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "settings.json");
                    if (File.Exists(oldPath))
                    {
                        readPath = oldPath;
                    }
                }

                if (File.Exists(readPath))
                {
                    loaded = JsonSerializer.Deserialize<SettingsData>(File.ReadAllText(readPath));
                }
            }
            catch
            {
                loaded = null;
            }

            if (loaded == null)
            {
                loaded = CreateDefault();
            }
            if (string.IsNullOrWhiteSpace(loaded.CompanyName))
            {
                loaded.CompanyName = DefaultCompany;
            }
            if (loaded.RolePermissions == null)
            {
                loaded.RolePermissions = new Dictionary<string, List<string>>();
            }
            if (loaded.EmployeePermissions == null)
            {
                loaded.EmployeePermissions = new Dictionary<int, List<string>>();
            }
            if (loaded.LeaderEmployeeIds == null)
            {
                loaded.LeaderEmployeeIds = new List<int>();
            }

            // 標準の身分が無ければ補う
            SettingsData def = CreateDefault();
            foreach (KeyValuePair<string, List<string>> p in def.RolePermissions)
            {
                if (!loaded.RolePermissions.ContainsKey(p.Key))
                {
                    loaded.RolePermissions[p.Key] = p.Value;
                }
            }

            data = loaded;
        }

        // ファイルに保存する（成功なら ""、失敗ならエラーメッセージ）
        private static string Save()
        {
            try
            {
                string? folder = Path.GetDirectoryName(filePath);
                if (folder != null && !Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                JsonSerializerOptions options = new JsonSerializerOptions();
                options.WriteIndented = true;
                options.Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;   // 日本語をそのまま保存

                File.WriteAllText(filePath, JsonSerializer.Serialize(Data, options));
                return "";
            }
            catch (Exception ex)
            {
                return "設定ファイルに保存できませんでした。\n（" + filePath + "）\n" + ex.Message;
            }
        }

        // 変更を保存する。失敗したときは、メモリ上の内容もファイルの状態に戻す
        private static string Commit()
        {
            string error = Save();
            if (error != "")
            {
                Load();
            }
            return error;
        }

        // ================= 会社名 =================

        public static string CompanyName
        {
            get { return Data.CompanyName; }
        }

        public static string SetCompanyName(string name)
        {
            Data.CompanyName = name;
            return Commit();
        }

        // ================= 身分ごとの権限 =================

        public static List<string> GetRolePermissions(string role)
        {
            if (Data.RolePermissions.ContainsKey(role))
            {
                return new List<string>(Data.RolePermissions[role]);
            }
            return new List<string>();
        }

        public static string SetRolePermissions(string role, List<string> moduleKeys)
        {
            if (role == LoginSession.RoleAdmin)
            {
                return "管理者の権限は変更できません";
            }

            Data.RolePermissions[role] = new List<string>(moduleKeys);
            return Commit();
        }

        // ================= 社員ごとの権限 =================

        // 個別設定があればその一覧、無ければ null
        public static List<string>? GetEmployeePermissions(int emId)
        {
            if (Data.EmployeePermissions.ContainsKey(emId))
            {
                return new List<string>(Data.EmployeePermissions[emId]);
            }
            return null;
        }

        public static string SetEmployeePermissions(int emId, List<string> moduleKeys)
        {
            Data.EmployeePermissions[emId] = new List<string>(moduleKeys);
            return Commit();
        }

        // 個別設定を解除する（身分の設定に従うようになる）
        public static string RemoveEmployeePermissions(int emId)
        {
            if (!Data.EmployeePermissions.ContainsKey(emId))
            {
                return "";
            }

            Data.EmployeePermissions.Remove(emId);
            return Commit();
        }

        // ================= リーダー =================

        public static bool IsLeader(int emId)
        {
            return Data.LeaderEmployeeIds.Contains(emId);
        }

        public static string SetLeader(int emId, bool leader)
        {
            bool now = Data.LeaderEmployeeIds.Contains(emId);
            if (leader == now)
            {
                return "";
            }

            if (leader)
            {
                Data.LeaderEmployeeIds.Add(emId);
            }
            else
            {
                Data.LeaderEmployeeIds.Remove(emId);
            }
            return Commit();
        }
    }
}