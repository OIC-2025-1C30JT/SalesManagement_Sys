﻿using System;
namespace SalesManagement_SysDev
{
    // 保存当前登录者的信息（全程序共用）
    public static class LoginSession
    {
        // 身份名称，和 Portal 的判断保持一致
        public const string RoleAdmin = "管理者";
        public const string RoleLogistics = "物流担当";
        public const string RoleSales = "営業担当";

        public static string UserId { get; private set; } = "";
        public static string UserName { get; private set; } = "";
        public static string Role { get; private set; } = "";
        public static int EmId { get; private set; } = 0;   // administrator 为 0（不在社員表中）
        public static int SoId { get; private set; } = 0;

        public static bool IsAdmin { get { return Role == RoleAdmin; } }

        public static void Set(string userId, string userName, string role, int emId, int soId)
        {
            UserId = userId;
            UserName = userName;
            Role = role;
            EmId = emId;
            SoId = soId;
        }

        // ログアウト时调用
        public static void Clear()
        {
            UserId = "";
            UserName = "";
            Role = "";
            EmId = 0;
            SoId = 0;
        }
        public static string GetRoleName(string positionName)
        {
            if (positionName.Contains("管理")) return RoleAdmin;
            if (positionName.Contains("物流")) return RoleLogistics;
            if (positionName.Contains("営業")) return RoleSales;
            return positionName;
        }

        // 標準の役職かどうか（標準の役職は非表示にできない）
        public static bool IsStandardPosition(string positionName)
        {
            return positionName.Contains("管理") || positionName.Contains("物流") || positionName.Contains("営業");
        }

        // administrator アカウントでログインしているか
        public static bool IsAdministrator
        {
            get { return string.Equals(UserId, AppConfig.AdminId, StringComparison.OrdinalIgnoreCase); }
        }
    }
}