﻿using System.Collections.Generic;

namespace SalesManagement_SysDev
{
    // 各身分が使えるモジュールの判定（固定の対応表）
    // 権限を変えたい場合は、社員管理で社員の「役職」を変更する（役職はデータベースに保存されるので、全端末に反映される）
    public static class ModulePermission
    {
        // 12 个模块的 Key
        public const string Employee = "Employee";       // 社員管理
        public const string Client = "Client";           // 顧客管理
        public const string Product = "Product";         // 商品管理
        public const string Stock = "Stock";             // 在庫管理
        public const string Order = "Order";             // 受注管理
        public const string Chumon = "Chumon";           // 注文管理
        public const string Sale = "Sale";               // 売上管理
        public const string Hattyu = "Hattyu";           // 発注管理
        public const string Warehousing = "Warehousing"; // 入庫管理
        public const string Syukko = "Syukko";           // 出庫管理
        public const string Arrival = "Arrival";         // 入荷管理
        public const string Shipment = "Shipment";       // 出荷管理

        // 管理者：全部（ポータルの表示順）
        private static readonly string[] AdminKeys = new string[]
        {
            Employee, Client, Product, Stock, Order, Chumon,
            Sale, Hattyu, Warehousing, Syukko, Arrival, Shipment
        };

        // 物流担当：商品、在庫、出庫、発注、入庫
        private static readonly string[] LogisticsKeys = new string[]
        {
            Product, Stock, Syukko, Hattyu, Warehousing
        };

        // 営業担当：顧客、受注、注文、入荷、出荷、売上
        private static readonly string[] SalesKeys = new string[]
        {
            Client, Order, Chumon, Sale, Arrival, Shipment
        };

        // 身分が使えるモジュールの一覧（未定義の身分は空）
        public static List<string> GetAllowedKeys(string role)
        {
            if (role == LoginSession.RoleAdmin)
            {
                return new List<string>(AdminKeys);
            }
            if (role == LoginSession.RoleLogistics)
            {
                return new List<string>(LogisticsKeys);
            }
            if (role == LoginSession.RoleSales)
            {
                return new List<string>(SalesKeys);
            }
            return new List<string>();
        }

        // 画面に表示するモジュール名
        public static string GetDisplayName(string key)
        {
            switch (key)
            {
                case Employee: return "社員管理";
                case Client: return "顧客管理";
                case Product: return "商品管理";
                case Stock: return "在庫管理";
                case Order: return "受注管理";
                case Chumon: return "注文管理";
                case Sale: return "売上管理";
                case Hattyu: return "発注管理";
                case Warehousing: return "入庫管理";
                case Syukko: return "出庫管理";
                case Arrival: return "入荷管理";
                case Shipment: return "出荷管理";
            }
            return key;
        }

        public static bool CanUse(string role, string moduleKey)
        {
            return GetAllowedKeys(role).Contains(moduleKey);
        }
    }
}