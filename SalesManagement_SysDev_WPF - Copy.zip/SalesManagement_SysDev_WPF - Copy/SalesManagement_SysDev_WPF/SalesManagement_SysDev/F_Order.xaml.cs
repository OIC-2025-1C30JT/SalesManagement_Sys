﻿
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Order : Window
    {
        public class OrderItem
        {
            public int PrId { get; set; }
            public string PrName { get; set; } = "";
            public int Quantity { get; set; }
            public decimal Price { get; set; }
            public decimal TotalPrice => Price * Quantity;
        }

        private readonly ObservableCollection<OrderItem> orderItems =
            new ObservableCollection<OrderItem>();

        private int? selectedOrderId;
        private bool isLoading;

        public F_Order()
        {
            InitializeComponent();
            lstOrderDetails.ItemsSource = orderItems;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadMasterData();
            LoadOrderData();
            ClearInput();
        }

        // マスターデータ取得
        private void LoadMasterData()
        {
            try
            {
                using var db = new SalesManagementContext();

                cmbClient.ItemsSource = db.MClients
                    .AsNoTracking()
                    .Where(x => x.ClFlag == 0)
                    .ToList()
                    .GroupBy(x => (x.ClName ?? "").Trim())
                    .Select(g => g.OrderBy(x => x.ClId).First())
                    .OrderBy(x => x.ClName)
                    .ToList();

                cmbEmployee.ItemsSource = db.MEmployees
                    .AsNoTracking()
                    .Where(x => x.EmFlag == 0)
                    .OrderBy(x => x.EmId)
                    .ToList();

                cmbProduct.ItemsSource = db.MProducts
                    .AsNoTracking()
                    .Where(x => x.PrFlag == 0)
                    .ToList()
                    .GroupBy(x => (x.PrName ?? "").Trim())
                    .Select(g => g.OrderBy(x => x.PrId).First())
                    .OrderBy(x => x.PrName)
                    .ToList();

                cmbClient.DisplayMemberPath = "ClName";
                cmbClient.SelectedValuePath = "ClId";

                cmbEmployee.DisplayMemberPath = "EmName";
                cmbEmployee.SelectedValuePath = "EmId";

                cmbProduct.DisplayMemberPath = "PrName";
                cmbProduct.SelectedValuePath = "PrId";

                cmbClient.SelectedIndex = -1;
                cmbEmployee.SelectedIndex = -1;
                cmbProduct.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                ShowError("マスターデータ取得エラー", ex);
            }
        }

        // 受注一覧
        private void LoadOrderData()
        {
            try
            {
                using var db = new SalesManagementContext();

                isLoading = true;

                dgOrder.ItemsSource = db.TOrders
                    .AsNoTracking()
                    .Where(x => x.OrFlag == 0)
                    .OrderByDescending(x => x.OrId)
                    .ToList();

                dgOrder.SelectedItem = null;
                selectedOrderId = null;
            }
            catch (Exception ex)
            {
                ShowError("受注一覧取得エラー", ex);
            }
            finally
            {
                isLoading = false;
            }
        }

        // 在庫チェック
        private bool CheckStock(
            SalesManagementContext db,
            int productId,
            int quantity)
        {
            int stock = db.TStocks
                .Where(x =>
                    x.PrId == productId &&
                    x.StFlag == 0)
                .Sum(x => (int?)x.StQuantity) ?? 0;

            if (quantity > stock)
            {
                MessageBox.Show(
                    "在庫数が不足しています。\n\n" +
                    $"商品ID：{productId}\n" +
                    $"現在庫数：{stock}\n" +
                    $"受注数量：{quantity}",
                    "在庫不足",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            return true;
        }

        // 商品追加
        private void BtnAddProduct_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (cmbProduct.SelectedItem is not MProduct product)
            {
                MessageBox.Show("商品を選択してください。");
                return;
            }

            if (!int.TryParse(txtQuantity.Text.Trim(),
                out int quantity) || quantity <= 0)
            {
                MessageBox.Show(
                    "数量は1以上の数字で入力してください。");
                return;
            }

            try
            {
                var existing = orderItems.FirstOrDefault(
                    x => x.PrId == product.PrId);

                int totalQuantity = checked(
                    (existing?.Quantity ?? 0) + quantity);

                using var db = new SalesManagementContext();

                if (!CheckStock(db, product.PrId, totalQuantity))
                    return;

                if (existing != null)
                {
                    existing.Quantity = totalQuantity;
                    lstOrderDetails.Items.Refresh();
                }
                else
                {
                    orderItems.Add(new OrderItem
                    {
                        PrId = product.PrId,
                        PrName = product.PrName,
                        Price = product.Price,
                        Quantity = quantity
                    });
                }

                UpdateTotal();

                cmbProduct.SelectedIndex = -1;
                txtQuantity.Clear();
                cmbProduct.Focus();
            }
            catch (OverflowException)
            {
                MessageBox.Show("数量が大きすぎます。");
            }
            catch (Exception ex)
            {
                ShowError("商品追加エラー", ex);
            }
        }

        // 商品削除
        private void BtnRemoveProduct_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (lstOrderDetails.SelectedItem is not OrderItem item)
            {
                MessageBox.Show(
                    "削除する商品を選択してください。");
                return;
            }

            orderItems.Remove(item);
            UpdateTotal();
        }

        // 合計金額
        private void UpdateTotal()
        {
            try
            {
                decimal total = orderItems.Sum(x => x.TotalPrice);

                txtItemCount.Text = orderItems.Count.ToString();
                txtTotalAmount.Text = total.ToString("N0") + " 円";
            }
            catch (OverflowException)
            {
                MessageBox.Show("合計金額が大きすぎます。");
            }
        }

        // 入力チェック
        private bool ValidateInput()
        {
            if (!dpOrderDate.SelectedDate.HasValue)
            {
                MessageBox.Show("受注日を選択してください。");
                return false;
            }

            if (cmbClient.SelectedValue == null)
            {
                MessageBox.Show("顧客を選択してください。");
                return false;
            }

            if (cmbEmployee.SelectedValue == null)
            {
                MessageBox.Show("社員を選択してください。");
                return false;
            }

            if (orderItems.Count == 0)
            {
                MessageBox.Show("商品を1つ以上追加してください。");
                return false;
            }

            if (orderItems.Any(x => x.Quantity <= 0))
            {
                MessageBox.Show("商品数量が正しくありません。");
                return false;
            }

            return true;
        }

        // 受注登録
        private void BtnInsert_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ValidateInput())
                return;

            int clientId = (int)cmbClient.SelectedValue;
            int employeeId = (int)cmbEmployee.SelectedValue;
            DateTime orderDate = dpOrderDate.SelectedDate.Value;

            try
            {
                using var db = new SalesManagementContext();
                using var transaction = db.Database.BeginTransaction(
                    System.Data.IsolationLevel.Serializable);

                // 登録前に在庫を再確認
                foreach (var item in orderItems)
                {
                    if (!CheckStock(db, item.PrId, item.Quantity))
                        return;
                }

                var client = db.MClients.FirstOrDefault(x =>
                    x.ClId == clientId && x.ClFlag == 0);

                if (client == null)
                {
                    MessageBox.Show("顧客が見つかりません。");
                    return;
                }

                if (!db.MEmployees.Any(x => x.EmId == employeeId))
                {
                    MessageBox.Show("社員が見つかりません。");
                    return;
                }

                var order = new TOrder
                {
                    SoId = client.SoId,
                    ClId = clientId,
                    EmId = employeeId,
                    OrDate = orderDate,
                    OrStateFlag = 0,
                    OrFlag = 0,
                    ClCharge = ""
                };

                db.TOrders.Add(order);
                db.SaveChanges();

                foreach (var item in orderItems)
                {
                    db.TOrderDetails.Add(new TOrderDetail
                    {
                        OrId = order.OrId,
                        PrId = item.PrId,
                        OrQuantity = item.Quantity,
                        OrTotalPrice = item.TotalPrice
                    });
                }

                db.SaveChanges();
                transaction.Commit();

                MessageBox.Show(
                    "受注登録が完了しました。\n" +
                    $"受注ID：{order.OrId}\n" +
                    $"商品種類数：{orderItems.Count}",
                    "登録完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                LoadOrderData();
                ClearInput();
            }
            catch (Exception ex)
            {
                ShowError("受注登録エラー", ex);
            }
        }

        // DataGrid 選択
        private void dgOrder_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (isLoading || dgOrder.SelectedItem is not TOrder selected)
                return;

            try
            {
                using var db = new SalesManagementContext();

                var order = db.TOrders.AsNoTracking()
                    .FirstOrDefault(x => x.OrId == selected.OrId);

                if (order == null)
                    return;

                selectedOrderId = order.OrId;

                txtOrderID.Text = order.OrId.ToString();
                dpOrderDate.SelectedDate = order.OrDate;
                cmbClient.SelectedValue = order.ClId;
                cmbEmployee.SelectedValue = order.EmId;

                txtOrderState.Text = order.OrStateFlag == 1
                    ? "確定済み" : "未確定";

                txtOrderFlag.Text = order.OrFlag == 0
                    ? "表示" : "非表示";

                var details = (
                    from d in db.TOrderDetails.AsNoTracking()
                    join p in db.MProducts.AsNoTracking()
                        on d.PrId equals p.PrId
                    where d.OrId == order.OrId
                    select new
                    {
                        d.PrId,
                        p.PrName,
                        d.OrQuantity,
                        d.OrTotalPrice
                    }).ToList();

                orderItems.Clear();

                foreach (var d in details)
                {
                    decimal price = d.OrQuantity > 0
                        ? d.OrTotalPrice / d.OrQuantity : 0;

                    orderItems.Add(new OrderItem
                    {
                        PrId = d.PrId,
                        PrName = d.PrName,
                        Quantity = d.OrQuantity,
                        Price = price
                    });
                }

                UpdateTotal();
            }
            catch (Exception ex)
            {
                ShowError("受注詳細取得エラー", ex);
            }
        }

        // 検索
        private void BtnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            string keyword = (txtSearch.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(keyword))
            {
                LoadOrderData();
                return;
            }

            try
            {
                using var db = new SalesManagementContext();

                var orders = db.TOrders.AsNoTracking()
                    .Where(x => x.OrFlag == 0)
                    .ToList();

                var clients = db.MClients.AsNoTracking()
                    .ToList()
                    .GroupBy(x => x.ClId)
                    .ToDictionary(
                        g => g.Key,
                        g => g.First().ClName ?? "");

                var employees = db.MEmployees.AsNoTracking()
                    .ToList()
                    .GroupBy(x => x.EmId)
                    .ToDictionary(
                        g => g.Key,
                        g => g.First().EmName ?? "");

                string normalized = keyword.Replace("-", "/");

                bool ContainsKeyword(string value) =>
                    value.IndexOf(
                        keyword,
                        StringComparison.OrdinalIgnoreCase) >= 0;

                bool ContainsDate(string value) =>
                    value.IndexOf(
                        normalized,
                        StringComparison.OrdinalIgnoreCase) >= 0;

                var results = orders.Where(order =>
                {
                    string clientName =
                        clients.TryGetValue(order.ClId, out var cn)
                            ? cn : "";

                    string employeeName =
                        employees.TryGetValue(order.EmId, out var en)
                            ? en : "";

                    string state = order.OrStateFlag == 1
                        ? "確定済み" : "未確定";

                    return ContainsKeyword(order.OrId.ToString())
                        || ContainsKeyword(order.ClId.ToString())
                        || ContainsKeyword(order.EmId.ToString())
                        || ContainsKeyword(clientName)
                        || ContainsKeyword(employeeName)
                        || ContainsKeyword(state)
                        || ContainsKeyword(order.OrStateFlag.ToString())
                        || ContainsDate(order.OrDate.ToString("yyyy/MM/dd"))
                        || ContainsDate(order.OrDate.ToString("yyyy/M/d"))
                        || ContainsDate(order.OrDate.ToString("yyyy/MM"))
                        || ContainsDate(order.OrDate.ToString("MM/dd"));
                })
                .OrderByDescending(x => x.OrId)
                .ToList();

                isLoading = true;
                dgOrder.ItemsSource = results;
                dgOrder.SelectedItem = null;
                selectedOrderId = null;
            }
            catch (Exception ex)
            {
                ShowError("検索エラー", ex);
            }
            finally
            {
                isLoading = false;
            }
        }

        // 受注更新
        private void BtnUpdate_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedOrderId.HasValue)
            {
                MessageBox.Show("更新する受注を選択してください。");
                return;
            }

            if (!ValidateInput())
                return;

            if (MessageBox.Show(
                "受注情報を更新しますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                using var db = new SalesManagementContext();
                using var transaction = db.Database.BeginTransaction(
                    System.Data.IsolationLevel.Serializable);

                var order = db.TOrders.FirstOrDefault(x =>
                    x.OrId == selectedOrderId.Value &&
                    x.OrFlag == 0);

                if (order == null)
                {
                    MessageBox.Show("受注が見つかりません。");
                    return;
                }

                if (order.OrStateFlag != 0)
                {
                    MessageBox.Show(
                        "確定済みの受注は更新できません。");
                    return;
                }

                // 更新前の在庫チェック
                foreach (var item in orderItems)
                {
                    if (!CheckStock(db, item.PrId, item.Quantity))
                        return;
                }

                int clientId = (int)cmbClient.SelectedValue;
                int employeeId = (int)cmbEmployee.SelectedValue;

                var client = db.MClients.FirstOrDefault(x =>
                    x.ClId == clientId && x.ClFlag == 0);

                if (client == null ||
                    !db.MEmployees.Any(x => x.EmId == employeeId))
                {
                    MessageBox.Show(
                        "顧客または社員が見つかりません。");
                    return;
                }

                order.ClId = clientId;
                order.SoId = client.SoId;
                order.EmId = employeeId;
                order.OrDate = dpOrderDate.SelectedDate.Value;

                var oldDetails = db.TOrderDetails
                    .Where(x => x.OrId == order.OrId)
                    .ToList();

                db.TOrderDetails.RemoveRange(oldDetails);

                foreach (var item in orderItems)
                {
                    db.TOrderDetails.Add(new TOrderDetail
                    {
                        OrId = order.OrId,
                        PrId = item.PrId,
                        OrQuantity = item.Quantity,
                        OrTotalPrice = item.TotalPrice
                    });
                }

                db.SaveChanges();
                transaction.Commit();

                MessageBox.Show("受注情報を更新しました。");

                LoadOrderData();
                ClearInput();
            }
            catch (Exception ex)
            {
                ShowError("受注更新エラー", ex);
            }
        }

        // 受注確定
        private void BtnConfirm_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedOrderId.HasValue)
            {
                MessageBox.Show(
                    "確定する受注を選択してください。");
                return;
            }

            if (MessageBox.Show(
                "この受注を確定しますか？",
                "受注確定",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                using var db = new SalesManagementContext();
                using var transaction = db.Database.BeginTransaction(
                    System.Data.IsolationLevel.Serializable);

                var order = db.TOrders.FirstOrDefault(x =>
                    x.OrId == selectedOrderId.Value &&
                    x.OrFlag == 0);

                if (order == null)
                {
                    MessageBox.Show("受注データがありません。");
                    return;
                }

                if (order.OrStateFlag != 0)
                {
                    MessageBox.Show(
                        "この受注は既に確定済みです。");
                    return;
                }

                if (db.TChumons.Any(x => x.OrId == order.OrId))
                {
                    MessageBox.Show(
                        "注文データは既に存在します。");
                    return;
                }

                var details = db.TOrderDetails
                    .Where(x => x.OrId == order.OrId)
                    .ToList();

                if (details.Count == 0)
                {
                    MessageBox.Show("受注詳細がありません。");
                    return;
                }

                if (details.Any(x => x.OrQuantity <= 0))
                {
                    MessageBox.Show(
                        "受注数量が正しくありません。");
                    return;
                }

                // 確定前の在庫チェック
                foreach (var group in details.GroupBy(x => x.PrId))
                {
                    int totalQuantity = checked(
                        group.Sum(x => x.OrQuantity));

                    if (!CheckStock(
                        db,
                        group.Key,
                        totalQuantity))
                        return;
                }

                var chumon = new TChumon
                {
                    OrId = order.OrId,
                    ClId = order.ClId,
                    SoId = order.SoId,
                    EmId = null,
                    ChDate = DateTime.Today,
                    ChStateFlag = 0,
                    ChFlag = 0
                };

                foreach (var detail in details)
                {
                    chumon.TChumonDetails.Add(
                        new TChumonDetail
                        {
                            PrId = detail.PrId,
                            ChQuantity = detail.OrQuantity
                        });
                }

                db.TChumons.Add(chumon);
                order.OrStateFlag = 1;

                db.SaveChanges();
                transaction.Commit();

                MessageBox.Show(
                    "受注確定が完了しました。\n" +
                    $"注文ID：{chumon.ChId}");

                LoadOrderData();
                ClearInput();
            }
            catch (Exception ex)
            {
                ShowError("受注確定エラー", ex);
            }
        }

        // 非表示
        private void BtnHide_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedOrderId.HasValue)
            {
                MessageBox.Show(
                    "非表示にする受注を選択してください。");
                return;
            }

            if (MessageBox.Show(
                "この受注を非表示にしますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                using var db = new SalesManagementContext();

                var order = db.TOrders.FirstOrDefault(x =>
                    x.OrId == selectedOrderId.Value &&
                    x.OrFlag == 0);

                if (order == null)
                {
                    MessageBox.Show("受注が見つかりません。");
                    return;
                }

                if (order.OrStateFlag != 0)
                {
                    MessageBox.Show(
                        "確定済みの受注は非表示にできません。");
                    return;
                }

                order.OrFlag = 2;
                db.SaveChanges();

                MessageBox.Show("受注を非表示にしました。");

                LoadOrderData();
                ClearInput();
            }
            catch (Exception ex)
            {
                ShowError("非表示エラー", ex);
            }
        }

        // 一覧表示
        private void BtnList_Click(
            object sender,
            RoutedEventArgs e)
        {
            txtSearch.Clear();
            LoadOrderData();
        }

        // クリア
        private void BtnClear_Click(
            object sender,
            RoutedEventArgs e)
        {
            ClearInput();
        }

        private void ClearInput()
        {
            isLoading = true;

            try
            {
                selectedOrderId = null;
                txtOrderID.Clear();
                dpOrderDate.SelectedDate = DateTime.Today;

                cmbClient.SelectedIndex = -1;
                cmbEmployee.SelectedIndex = -1;
                cmbProduct.SelectedIndex = -1;

                txtQuantity.Clear();
                txtOrderState.Text = "未確定";
                txtOrderFlag.Text = "表示";

                orderItems.Clear();
                UpdateTotal();

                dgOrder.SelectedItem = null;
            }
            finally
            {
                isLoading = false;
            }
        }

        // 閉じる
        private void BtnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (MessageBox.Show(
                "受注管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Close();
            }
        }

        // エラー表示
        private void ShowError(string title, Exception ex)
        {
            MessageBox.Show(
                title + "\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
