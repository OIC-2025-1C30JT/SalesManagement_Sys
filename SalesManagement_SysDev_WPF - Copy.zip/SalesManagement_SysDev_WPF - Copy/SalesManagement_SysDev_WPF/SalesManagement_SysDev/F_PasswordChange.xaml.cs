﻿using Microsoft.Identity.Client;
using System.ComponentModel.DataAnnotations;
using System.Windows;

namespace SalesManagement_SysDev
{
    public partial class F_PasswordChange : Window
    {
        public F_PasswordChange(string defaultId)
        {
            InitializeComponent();
            txtEmID.Text = defaultId;
        }

        // 1.1 パスワード変更機能
        private void btnChange_Click(object sender, RoutedEventArgs e)
        {
            string id = txtEmID.Text.Trim();
            string current = txtCurrent.Password;
            string newPw = txtNew.Password;
            string confirm = txtConfirm.Password;

            if (id == "")
            {
                MessageBox.Show("社員IDを入力してください");
                return;
            }

            if (string.Equals(id, AppConfig.AdminId, StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("administrator のパスワードは AppConfig.cs で変更してください");
                return;
            }

            int empid;
            if (!int.TryParse(id, out empid))
            {
                MessageBox.Show("社員IDは数字で入力してください");
                return;
            }

            // 锁定检查（现在的密码也算入错误次数）
            int remain;
            if (LoginLockManager.IsLocked(id, out remain))
            {
                MessageBox.Show("アカウントがロックされています。\nあと約 " + remain + " 分後に再度お試しください。");
                return;
            }

            if (!Validator.IsValidPassword(newPw))
            {
                MessageBox.Show(Validator.PasswordRuleText);
                return;
            }
            if (newPw != confirm)
            {
                MessageBox.Show("新しいパスワードが一致しません");
                return;
            }
            if (newPw == current)
            {
                MessageBox.Show("現在のパスワードと同じです。別のパスワードを入力してください");
                return;
            }

            try
            {
                using SalesManagementContext context = new SalesManagementContext();

                var employee = context.MEmployees
                                      .FirstOrDefault(x => x.EmId == empid &&
                                                           x.EmPassword == current &&
                                                           x.EmFlag == 0);
                if (employee == null)
                {
                    bool locked = LoginLockManager.RecordFail(id);
                    if (locked)
                    {
                        MessageBox.Show("パスワードを5回連続で間違えました。\nアカウントを15分間ロックします。");
                    }
                    else
                    {
                        MessageBox.Show("社員IDまたは現在のパスワードが違います");
                    }
                    return;
                }

                employee.EmPassword = newPw;
                context.SaveChanges();
                LoginLockManager.Reset(id);

                MessageBox.Show("パスワードを変更しました");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("データベースエラー：" + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}