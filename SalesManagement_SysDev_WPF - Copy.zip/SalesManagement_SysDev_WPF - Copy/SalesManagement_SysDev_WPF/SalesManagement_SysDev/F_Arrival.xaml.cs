﻿
using System;
using System.Data;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Arrival : Window
    {
        public F_Arrival()
        {
            InitializeComponent();
        }

        // =========================================
        // DataGrid 表示用
        // =========================================
        private class ArrivalRow
        {
            public int HattyuId { get; set; }

            public DateTime HattyuDate { get; set; }

            public int ProductId { get; set; }

            public string ProductName { get; set; } = "";

            public int Quantity { get; set; }

            public string OrderStatus { get; set; } = "";

            public string WarehouseStatus { get; set; } = "";
        }

        // =========================================
        // Window Loaded
        // =========================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            LoadData();
        }

        // =========================================
        // 入庫一覧表示
        // =========================================
        private void LoadData(
            int? hattyuId = null,
            string productName = "",
            bool unreceivedOnly = false)
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query = context.THattyuDetails
                    .AsNoTracking()
                    .Where(x => x.Ha.HaHidden != "1");

                if (hattyuId.HasValue)
                {
                    query = query.Where(
                        x => x.HaId == hattyuId.Value);
                }

                if (!string.IsNullOrWhiteSpace(productName))
                {
                    query = query.Where(
                        x => x.Pr.PrName.Contains(productName));
                }

                if (unreceivedOnly)
                {
                    query = query.Where(
                        x => x.Ha.WaWarehouseFlag == 0);
                }

                var data = query
                    .Select(x => new ArrivalRow
                    {
                        HattyuId = x.HaId,

                        HattyuDate = x.Ha.HaDate,

                        ProductId = x.PrId,

                        ProductName = x.Pr.PrName,

                        Quantity = x.HaQuantity,

                        OrderStatus =
                            x.Ha.HaFlag == 1
                                ? "確定"
                                : "未確定",

                        WarehouseStatus =
                            x.Ha.WaWarehouseFlag == 1
                                ? "入庫済"
                                : "未入庫"
                    })
                    .OrderByDescending(x => x.HattyuId)
                    .ToList();

                dgArrival.ItemsSource = data;
            }
            catch (Exception ex)
            {
                ShowError("入庫一覧取得エラー", ex);
            }
        }

        // =========================================
        // 検索
        // =========================================
        private void btnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            int? hattyuId = null;

            string idText = txtHattyuId.Text.Trim();
            string productName = txtSearch.Text.Trim();

            if (!string.IsNullOrWhiteSpace(idText))
            {
                if (!int.TryParse(idText, out int id))
                {
                    MessageBox.Show(
                        "発注番号は数字で入力してください。");
                    return;
                }

                hattyuId = id;
            }

            LoadData(hattyuId, productName);

            if (dgArrival.Items.Count == 0)
            {
                MessageBox.Show(
                    "該当する入庫データがありません。");
            }
        }

        // =========================================
        // 一覧表示
        // =========================================
        private void btnReload_Click(
            object sender,
            RoutedEventArgs e)
        {
            txtHattyuId.Clear();
            txtSearch.Clear();

            LoadData();
        }

        // =========================================
        // 未入庫一覧
        // =========================================
        private void btnUnreceived_Click(
            object sender,
            RoutedEventArgs e)
        {
            LoadData(unreceivedOnly: true);
        }

        // =========================================
        // 入庫確定
        // =========================================
        private void btnConfirm_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (dgArrival.SelectedItem
                is not ArrivalRow selected)
            {
                MessageBox.Show(
                    "入庫する発注データを選択してください。");
                return;
            }

            if (MessageBox.Show(
                $"発注番号 {selected.HattyuId} を入庫確定しますか？\n" +
                "この発注に含まれる商品をすべて入庫します。",
                "入庫確定",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                using var transaction =
                    context.Database.BeginTransaction(
                        IsolationLevel.Serializable);

                // 発注データ取得
                var hattyu = context.THattyus
                    .FirstOrDefault(x =>
                        x.HaId == selected.HattyuId &&
                        x.HaHidden != "1");

                if (hattyu == null)
                {
                    MessageBox.Show(
                        "発注データが見つかりません。");
                    return;
                }

                // 発注確定チェック
                if (hattyu.HaFlag != 1)
                {
                    MessageBox.Show(
                        "発注確定されていません。\n" +
                        "先に発注管理で確定してください。");
                    return;
                }

                // 二重入庫防止
                if (hattyu.WaWarehouseFlag == 1)
                {
                    MessageBox.Show(
                        "この発注は既に入庫済みです。");
                    return;
                }

                // 発注詳細取得
                var details = context.THattyuDetails
                    .Where(x => x.HaId == hattyu.HaId)
                    .ToList();

                if (details.Count == 0)
                {
                    MessageBox.Show(
                        "発注詳細がありません。");
                    return;
                }

                if (details.Any(x => x.HaQuantity <= 0))
                {
                    MessageBox.Show(
                        "発注数量が正しくありません。");
                    return;
                }

                // =====================================
                // 在庫数量を増やす
                // =====================================
                foreach (var detail in details)
                {
                    var stock = context.TStocks
                        .FirstOrDefault(x =>
                            x.PrId == detail.PrId &&
                            x.StFlag == 0);

                    if (stock == null)
                    {
                        // 在庫データがない場合は新規作成
                        stock = new TStock
                        {
                            PrId = detail.PrId,
                            StQuantity = detail.HaQuantity,
                            StFlag = 0
                        };

                        context.TStocks.Add(stock);
                    }
                    else
                    {
                        // 既存在庫に加算
                        stock.StQuantity =
                            checked(stock.StQuantity +
                                    detail.HaQuantity);
                    }
                }

                // 入庫済みに更新
                hattyu.WaWarehouseFlag = 1;

                // 在庫と入庫状態を同時に保存
                context.SaveChanges();

                transaction.Commit();

                MessageBox.Show(
                    "入庫確定が完了しました。\n" +
                    "発注番号: " + hattyu.HaId +
                    "\n在庫数量を更新しました。",
                    "完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                LoadData();
            }
            catch (Exception ex)
            {
                ShowError("入庫確定エラー", ex);
            }
        }

        // =========================================
        // エラー表示
        // =========================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                title + ":\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)

        {
            this.Close();
        }

        private void Window_Closing(
            object sender,
            System.ComponentModel.CancelEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "入庫管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
            {
                e.Cancel = true;
            }
        }
    }
}
    