﻿
using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Chumon : Window
    {
        private readonly int? _employeeId;

        public F_Chumon(int? employeeId = null)
        {
            InitializeComponent();
            _employeeId = employeeId;
        }

        private void Window_Loaded(
            object sender, RoutedEventArgs e)
        {
            LoadChumonData();
        }

        // 9.1 注文一覧表示
        private void LoadChumonData()
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                dgChumon.ItemsSource = context.TChumons
                    .AsNoTracking()
                    .Where(x => x.ChFlag == 0)
                    .OrderByDescending(x => x.ChId)
                    .ToList();
            }
            catch (Exception ex)
            {
                ShowError("注文一覧取得エラー", ex);
            }
        }

        // 9.2 注文検索
        private void BtnSearch_Click(
            object sender, RoutedEventArgs e)
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query = context.TChumons
                    .AsNoTracking()
                    .Where(x => x.ChFlag == 0);

                if (!string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    if (!int.TryParse(
                        txtSearch.Text.Trim(),
                        out int clientId))
                    {
                        MessageBox.Show(
                            "顧客IDは数字で入力してください。");
                        return;
                    }

                    query = query.Where(x =>
                        x.ClId == clientId);
                }

                if (dpSearchDate.SelectedDate.HasValue)
                {
                    DateTime date =
                        dpSearchDate.SelectedDate.Value.Date;

                    DateTime nextDate = date.AddDays(1);

                    query = query.Where(x =>
                        x.ChDate >= date &&
                        x.ChDate < nextDate);
                }

                dgChumon.ItemsSource = query
                    .OrderByDescending(x => x.ChId)
                    .ToList();
            }
            catch (Exception ex)
            {
                ShowError("注文検索エラー", ex);
            }
        }

        // 9.3 注文非表示
        private void BtnHide_Click(
            object sender, RoutedEventArgs e)
        {
            if (dgChumon.SelectedItem is not TChumon selected)
            {
                MessageBox.Show(
                    "非表示にする注文を選択してください。");
                return;
            }

            if (MessageBox.Show(
                $"注文ID {selected.ChId} を非表示にしますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                var chumon = context.TChumons
                    .FirstOrDefault(x =>
                        x.ChId == selected.ChId &&
                        x.ChFlag == 0);

                if (chumon == null)
                {
                    MessageBox.Show(
                        "注文データが見つかりません。");
                    LoadChumonData();
                    return;
                }

                if (chumon.ChStateFlag == 1)
                {
                    MessageBox.Show(
                        "確定済みの注文は非表示にできません。");
                    return;
                }

                chumon.ChFlag = 2;
                context.SaveChanges();

                MessageBox.Show(
                    "注文を非表示にしました。");

                LoadChumonData();
            }
            catch (Exception ex)
            {
                ShowError("注文非表示エラー", ex);
            }
        }

        // 9.4 注文確定
        private void BtnConfirm_Click(
            object sender, RoutedEventArgs e)
        {
            if (dgChumon.SelectedItem is not TChumon selected)
            {
                MessageBox.Show(
                    "確定する注文を選択してください。");
                return;
            }

            if (!_employeeId.HasValue)
            {
                MessageBox.Show(
                    "担当社員IDが設定されていません。\n" +
                    "ログイン中の社員IDを渡してください。");
                return;
            }

            if (MessageBox.Show(
                $"注文ID {selected.ChId} を確定しますか？",
                "注文確定",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                using var transaction =
                    context.Database.BeginTransaction(
                        System.Data.IsolationLevel.Serializable);

                // 注文と詳細を取得
                var chumon = context.TChumons
                    .Include(x => x.TChumonDetails)
                    .FirstOrDefault(x =>
                        x.ChId == selected.ChId &&
                        x.ChFlag == 0);

                if (chumon == null)
                {
                    MessageBox.Show(
                        "注文データが見つかりません。");
                    return;
                }

                if (chumon.ChStateFlag != 0)
                {
                    MessageBox.Show(
                        "この注文は確定できません。");
                    return;
                }

                var details =
                    chumon.TChumonDetails.ToList();

                if (details.Count == 0)
                {
                    MessageBox.Show(
                        "注文詳細がありません。");
                    return;
                }

                if (details.Any(x => x.ChQuantity <= 0))
                {
                    MessageBox.Show(
                        "注文数量が正しくありません。");
                    return;
                }

                // 出庫重複チェック
                if (context.TSyukkos.Any(x =>
                    x.OrId == chumon.OrId))
                {
                    MessageBox.Show(
                        "この受注の出庫データは既に存在します。");
                    return;
                }

                // 商品ごとに必要数量を合計
                var requiredItems = details
                    .GroupBy(x => x.PrId)
                    .Select(g => new
                    {
                        PrId = g.Key,
                        Quantity = g.Sum(x => x.ChQuantity)
                    })
                    .ToList();

                // 在庫確認・減算
                foreach (var item in requiredItems)
                {
                    var stock = context.TStocks
                        .FirstOrDefault(x =>
                            x.PrId == item.PrId &&
                            x.StFlag == 0);

                    if (stock == null)
                    {
                        MessageBox.Show(
                            $"商品ID {item.PrId} の在庫がありません。");
                        return;
                    }

                    if (stock.StQuantity < item.Quantity)
                    {
                        MessageBox.Show(
                            $"商品ID {item.PrId} の在庫が不足しています。\n" +
                            $"現在庫: {stock.StQuantity}\n" +
                            $"必要数量: {item.Quantity}");
                        return;
                    }

                    stock.StQuantity -= item.Quantity;
                }

                // 出庫ヘッダー作成
                var syukko = new TSyukko
                {
                    OrId = chumon.OrId,
                    ClId = chumon.ClId,
                    SoId = chumon.SoId,
                    EmId = null,
                    SyDate = null,
                    SyStateFlag = 0,
                    SyFlag = 0
                };

                // 出庫詳細作成
                foreach (var detail in details)
                {
                    syukko.TSyukkoDetails.Add(
                        new TSyukkoDetail
                        {
                            PrId = detail.PrId,
                            SyQuantity = detail.ChQuantity
                        });
                }

                context.TSyukkos.Add(syukko);

                // 注文確定
                chumon.ChStateFlag = 1;
                chumon.EmId = _employeeId.Value;

                context.SaveChanges();
                transaction.Commit();

                MessageBox.Show(
                    "注文確定が完了しました。\n" +
                    "出庫ID: " + syukko.SyId);

                LoadChumonData();
            }
            catch (Exception ex)
            {
                ShowError("注文確定エラー", ex);
            }
        }

        private void BtnShowAll_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Clear();
            dpSearchDate.SelectedDate = null;

            // 既存の一覧読み込み処理を呼び出す
            // 例: LoadChumonData();
        }


        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closing(
            object sender,
            System.ComponentModel.CancelEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "注文管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
            {
                e.Cancel = true;
            }
        }


        private void ShowError(
            string title, Exception ex)
        {
            MessageBox.Show(
                title + ":\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
