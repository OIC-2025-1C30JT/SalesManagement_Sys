﻿
using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Hattyu_History : Window
    {
        private readonly SalesManagementContext context;

        public F_Hattyu_History()
        {
            InitializeComponent();

            context = new SalesManagementContext();

            Loaded += (s, e) => LoadHistory();
            Closed += (s, e) => context.Dispose();
        }

        // 発注履歴を取得
        private void LoadHistory(
            int? hattyuId = null,
            string productName = "")
        {
            try
            {
                var query = context.THattyuDetails
                    .AsNoTracking()
                    .AsQueryable();

                // 発注番号で検索
                if (hattyuId.HasValue)
                {
                    int id = hattyuId.Value;
                    query = query.Where(x => x.HaId == id);
                }

                // 商品名で検索
                if (!string.IsNullOrWhiteSpace(productName))
                {
                    query = query.Where(
                        x => x.Pr.PrName.Contains(productName));
                }

                var data = query
                    .Select(x => new HattyuDisplayModel
                    {
                        HattyuId = x.HaId,
                        HattyuDate = x.Ha.HaDate,
                        ProductName = x.Pr.PrName,
                        Quantity = x.HaQuantity,
                        TotalPrice = x.Pr.Price * x.HaQuantity,

                        Status = x.Ha.HaHidden == "2"
                            ? "非表示"
                            : x.Ha.WaWarehouseFlag != 0
                                ? "入庫済み"
                                : x.Ha.HaFlag == 1
                                    ? "確定・未入庫"
                                    : "未確定"
                    })
                    .OrderByDescending(x => x.HattyuDate)
                    .ThenByDescending(x => x.HattyuId)
                    .ToList();

                dgHistory.ItemsSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.InnerException?.Message ?? ex.Message,
                    "履歴取得エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // 検索
       


        // 閉じる
        private void btnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            Close();
        }
    }
}
