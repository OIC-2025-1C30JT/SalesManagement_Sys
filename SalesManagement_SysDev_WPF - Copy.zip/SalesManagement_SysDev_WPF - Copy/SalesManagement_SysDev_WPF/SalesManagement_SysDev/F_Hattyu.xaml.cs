﻿
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Hattyu : Window
    {
        private readonly SalesManagementContext context;

        public F_Hattyu()
        {
            InitializeComponent();

            context = new SalesManagementContext();

            LoadMasterData();
            LoadHattyuData();

            Closed += (s, e) => context.Dispose();
        }

        // ==========================================
        // Master Data
        // ==========================================

        private void LoadMasterData()
        {
            try
            {
                // メーカー：同じ名前は1件だけ表示
                var makers = context.MMakers
                    .AsNoTracking()
                    .ToList()
                    .GroupBy(x => (x.MaName ?? "").Trim())
                    .Select(g => g.OrderBy(x => x.MaId).First())
                    .OrderBy(x => x.MaName)
                    .ToList();

                cmbMaker.ItemsSource = makers;
                cmbMaker.DisplayMemberPath = "MaName";
                cmbMaker.SelectedValuePath = "MaId";

                // 社員：同じ社員IDは1件だけ表示
                var employees = context.MEmployees
                    .AsNoTracking()
                    .Where(x => x.EmFlag == 0)
                    .OrderBy(x => x.EmId)
                    .ToList();

                cmbEmployee.ItemsSource = employees;
                cmbEmployee.DisplayMemberPath = "EmName";
                cmbEmployee.SelectedValuePath = "EmId";

                // 商品：同じ名前は1件だけ表示
                var products = context.MProducts
                    .AsNoTracking()
                    .Where(x => x.PrFlag == 0)
                    .ToList()
                    .GroupBy(x => (x.PrName ?? "").Trim())
                    .Select(g => g.OrderBy(x => x.PrId).First())
                    .OrderBy(x => x.PrName)
                    .ToList();

                cmbProduct.ItemsSource = products;
                cmbProduct.DisplayMemberPath = "PrName";
                cmbProduct.SelectedValuePath = "PrId";

                // 最初は未選択
                cmbMaker.SelectedIndex = -1;
                cmbEmployee.SelectedIndex = -1;
                cmbProduct.SelectedIndex = -1;

                txtPrice.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.GetBaseException().Message,
                    "マスターデータ取得エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }


        // ==========================================
        // 商品選択
        // ==========================================
        private void cmbProduct_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (cmbProduct.SelectedItem is MProduct product)
            {
                txtPrice.Text = product.Price.ToString("N0");
            }
            else
            {
                txtPrice.Clear();
            }
        }

        // ==========================================
        // 10.1 発注登録
        // ==========================================
        private void btnSaveOrder_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (cmbMaker.SelectedItem is not MMaker maker)
            {
                MessageBox.Show("メーカーを選択してください。");
                return;
            }

            if (cmbEmployee.SelectedItem is not MEmployee employee)
            {
                MessageBox.Show("社員を選択してください。");
                return;
            }

            if (cmbProduct.SelectedItem is not MProduct product)
            {
                MessageBox.Show("商品を選択してください。");
                return;
            }

            if (!int.TryParse(txtQuantity.Text, out int quantity))
            {
                MessageBox.Show("数量は数字で入力してください。");
                return;
            }

            if (quantity <= 0)
            {
                MessageBox.Show("数量は1以上にしてください。");
                return;
            }

            try
            {
                using var transaction =
                    context.Database.BeginTransaction();

                // 発注基本情報
                THattyu hattyu = new THattyu()
                {
                    MaId = maker.MaId,
                    EmId = employee.EmId,
                    HaDate = DateTime.Now,
                    WaWarehouseFlag = 0,
                    HaFlag = 0,
                    HaHidden = "0"
                };

                context.THattyus.Add(hattyu);
                context.SaveChanges();

                // 発注明細
                THattyuDetail detail = new THattyuDetail()
                {
                    HaId = hattyu.HaId,
                    PrId = product.PrId,
                    HaQuantity = quantity
                };

                context.THattyuDetails.Add(detail);
                context.SaveChanges();

                transaction.Commit();

                MessageBox.Show(
                    "発注登録が完了しました。",
                    "発注登録",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                LoadHattyuData();

                // 入力欄を初期化
                cmbMaker.SelectedIndex = -1;
                cmbEmployee.SelectedIndex = -1;
                cmbProduct.SelectedIndex = -1;
                txtPrice.Clear();
                txtQuantity.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.InnerException?.Message ?? ex.Message,
                    "発注登録エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ==========================================
        // 発注一覧
        // ==========================================
        private void LoadHattyuData()
        {
            var data = context.THattyuDetails
                .AsNoTracking()
                .Where(x => x.Ha.HaHidden == "0")
                .Select(x => new HattyuDisplayModel
                {
                    HattyuId = x.HaId,
                    HattyuDate = x.Ha.HaDate,
                    ProductName = x.Pr.PrName,
                    Quantity = x.HaQuantity,
                    TotalPrice = x.Pr.Price * x.HaQuantity,
                    Status = x.Ha.HaFlag == 1
                        ? "確定"
                        : "未確定"
                })
                .ToList();

            dgHattyu.ItemsSource = data;
        }

        // ==========================================
        // 発注登録欄へ移動
        // ==========================================
        private void btnHattyuRegister_Click(
            object sender,
            RoutedEventArgs e)
        {
            cmbMaker.Focus();
        }

        // ==========================================
      
       

        // ==========================================
        // 一覧表示
        // ==========================================
        private void btnSearchHattyu_Click(
            object sender,
            RoutedEventArgs e)
        {
            txtHattyuId.Clear();
            txtProductName.Clear();

            LoadHattyuData();
        }

        // ==========================================
        // 検索
        // ==========================================
        private void btnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            string idText = txtHattyuId.Text.Trim();
            string productName = txtProductName.Text.Trim();

            int? hattyuId = null;

            if (!string.IsNullOrEmpty(idText))
            {
                if (!int.TryParse(idText, out int id))
                {
                    MessageBox.Show(
                        "発注番号は数字で入力してください。");
                    return;
                }

                hattyuId = id;
            }

            var query = context.THattyuDetails
                .AsNoTracking()
                .Where(x => x.Ha.HaHidden == "0");

            if (hattyuId.HasValue)
            {
                int id = hattyuId.Value;

                query = query.Where(x => x.HaId == id);
            }

            if (!string.IsNullOrEmpty(productName))
            {
                query = query.Where(
                    x => x.Pr.PrName.Contains(productName));
            }

            var data = query
                .Select(x => new HattyuDisplayModel
                {
                    HattyuId = x.HaId,
                    HattyuDate = x.Ha.HaDate,
                    ProductName = x.Pr.PrName,
                    Quantity = x.HaQuantity,
                    TotalPrice = x.Pr.Price * x.HaQuantity,
                    Status = x.Ha.HaFlag == 1
                        ? "確定"
                        : "未確定"
                })
                .ToList();

            dgHattyu.ItemsSource = data;

            if (data.Count == 0)
            {
                MessageBox.Show(
                    "該当する発注データがありません。");
            }
        }

        // ==========================================
        // 10.5 発注確定
        // ==========================================
        private void btnConfirm_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (dgHattyu.SelectedItem
                is not HattyuDisplayModel selected)
            {
                MessageBox.Show(
                    "確定する発注を選択してください。");
                return;
            }

            THattyu? hattyu = context.THattyus
                .FirstOrDefault(x =>
                    x.HaId == selected.HattyuId);

            if (hattyu == null)
            {
                MessageBox.Show(
                    "発注データが見つかりません。");
                return;
            }

            if (hattyu.HaHidden != "0")
            {
                MessageBox.Show(
                    "非表示の発注は確定できません。");
                return;
            }

            if (hattyu.HaFlag == 1)
            {
                MessageBox.Show(
                    "この発注はすでに確定されています。");
                return;
            }

            try
            {
                hattyu.HaFlag = 1;
                context.SaveChanges();

                MessageBox.Show(
                    "発注を確定しました。");

                LoadHattyuData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.InnerException?.Message ?? ex.Message,
                    "発注確定エラー");
            }
        }

        // ==========================================
        // 非表示
        // ==========================================
        private void btnHide_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (dgHattyu.SelectedItem
                is not HattyuDisplayModel selected)
            {
                MessageBox.Show(
                    "非表示にする発注を選択してください。");
                return;
            }

            THattyu? hattyu = context.THattyus
                .FirstOrDefault(x =>
                    x.HaId == selected.HattyuId);

            if (hattyu == null)
            {
                MessageBox.Show(
                    "発注データが見つかりません。");
                return;
            }

            // 入庫済みデータは非表示にしない
            if (hattyu.WaWarehouseFlag != 0)
            {
                MessageBox.Show(
                    "入庫済みの発注は非表示にできません。");
                return;
            }

            var result = MessageBox.Show(
                "この発注を非表示にしますか？",
                "非表示確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;

            try
            {
                hattyu.HaHidden = "2";
                context.SaveChanges();

                MessageBox.Show(
                    "発注を非表示にしました。");

                LoadHattyuData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.InnerException?.Message ?? ex.Message,
                    "非表示エラー");
            }
        }
        private void btnHistory_Click(
      object sender,
      RoutedEventArgs e)
        {
            F_Hattyu_History history = new F_Hattyu_History();

            history.Owner = this;
            history.ShowDialog();
        }
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "発注管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }
    }


    // ==========================================
    // DataGrid 表示用
    // ==========================================
    public class HattyuDisplayModel
    {
        public int HattyuId { get; set; }

        public DateTime HattyuDate { get; set; }

        public string ProductName { get; set; } = "";

        public int Quantity { get; set; }

        public decimal TotalPrice { get; set; }

        public string Status { get; set; } = "";
    }
}
