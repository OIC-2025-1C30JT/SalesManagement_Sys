﻿namespace SalesManagement_SysDev
{
    // 固定设定（初学者版本直接写在代码里，以后可以改成配置文件）
    public static class AppConfig
    {
        public const string AdminId = "administrator";
        public const string AdminPassword = "admin1234";   // 请自行修改
        public const string AdminName = "システム管理者";
        // 会社名（固定。画面から変更はできない）
        public const string CompanyName = "AA22";
    }
}