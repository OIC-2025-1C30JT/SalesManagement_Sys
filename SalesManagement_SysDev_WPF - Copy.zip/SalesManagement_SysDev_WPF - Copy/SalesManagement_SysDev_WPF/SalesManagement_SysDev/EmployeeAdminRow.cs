﻿
namespace SalesManagement_SysDev
{
    public class EmployeeAdminRow
    {
        public int EmId { get; set; }

        public string EmName { get; set; } = "";

        public string SoName { get; set; } = "";

        public string PoName { get; set; } = "";

        public string RoleName { get; set; } = "";

        // 使えるモジュール
        public string AllowedModules { get; set; } = "";

        public bool IsLeader { get; set; }

        public bool HasPersonal { get; set; }

        public string GroupText =>
            IsLeader ? "リーダー" : "一般";

        public string PersonalText =>
            HasPersonal ? "あり" : "なし";
    }
}
