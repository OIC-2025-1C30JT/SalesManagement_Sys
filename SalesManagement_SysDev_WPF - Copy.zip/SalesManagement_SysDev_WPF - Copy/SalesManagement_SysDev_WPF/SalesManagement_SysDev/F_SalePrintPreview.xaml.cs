﻿
using System;
using System.IO;
using System.IO.Packaging;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;

namespace SalesManagement_SysDev
{
    public partial class F_SalePrintPreview : Window
    {
        private readonly MemoryStream xpsStream;
        private readonly Package xpsPackage;
        private readonly XpsDocument xpsDocument;
        private readonly Uri packageUri;

        // =====================================
        // コンストラクター
        // =====================================
        public F_SalePrintPreview(
            FlowDocument reportDocument)
        {
            InitializeComponent();

            // A4サイズ
            reportDocument.PageWidth = 793.7;
            reportDocument.PageHeight = 1122.5;
            reportDocument.PagePadding =
                new Thickness(45);

            reportDocument.ColumnWidth = 700;
            reportDocument.ColumnGap = 0;

            // XPS作成
            xpsStream = new MemoryStream();

            xpsPackage = Package.Open(
                xpsStream,
                FileMode.Create,
                FileAccess.ReadWrite);

            string uriText =
                "memorystream://" +
                Guid.NewGuid().ToString("N") +
                ".xps";

            packageUri = new Uri(uriText);

            PackageStore.AddPackage(
                packageUri,
                xpsPackage);

            xpsDocument = new XpsDocument(
                xpsPackage,
                CompressionOption.Normal,
                uriText);

            XpsDocumentWriter writer =
                XpsDocument.CreateXpsDocumentWriter(
                    xpsDocument);

            IDocumentPaginatorSource source =
                reportDocument;

            writer.Write(source.DocumentPaginator);

            documentViewer.Document =
                xpsDocument.GetFixedDocumentSequence();

            Closed += Preview_Closed;
        }

        // =====================================
        // PDF保存
        // =====================================
        private void btnPdf_Click(
            object sender,
            RoutedEventArgs e)
        {
            SavePdf();
        }

        private void SavePdf()
        {
            try
            {
                using LocalPrintServer server =
                    new LocalPrintServer();

                using PrintQueue pdfPrinter =
                    server.GetPrintQueue(
                        "Microsoft Print to PDF");

                XpsDocumentWriter writer =
                    PrintQueue.CreateXpsDocumentWriter(
                        pdfPrinter);

                IDocumentPaginatorSource source =
                    xpsDocument.GetFixedDocumentSequence();

                // WindowsのPDF保存ダイアログを表示
                writer.Write(
                    source.DocumentPaginator);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "PDF保存に失敗しました。\n" +
                    ex.GetBaseException().Message,
                    "エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // =====================================
        // 印刷ボタン
        // =====================================
        private void btnPrint_Click(
            object sender,
            RoutedEventArgs e)
        {
            PrintReport();
        }

        // =====================================
        // 印刷処理
        // =====================================
        private void PrintReport()
        {
            try
            {
                PrintDialog dialog =
                    new PrintDialog();

                if (dialog.ShowDialog() != true)
                {
                    return;
                }

                IDocumentPaginatorSource source =
                    xpsDocument.GetFixedDocumentSequence();

                dialog.PrintDocument(
                    source.DocumentPaginator,
                    "売上集計報告書");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "印刷処理に失敗しました。\n" +
                    ex.GetBaseException().Message,
                    "エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // =====================================
        // 閉じる
        // =====================================
        private void btnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            Close();
        }

        // =====================================
        // リソース解放
        // =====================================
        private void Preview_Closed(
            object? sender,
            EventArgs e)
        {
            documentViewer.Document = null;

            xpsDocument.Close();

            PackageStore.RemovePackage(
                packageUri);

            xpsPackage.Close();

            xpsStream.Dispose();
        }
    }
}
