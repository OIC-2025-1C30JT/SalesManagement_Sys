﻿
using System;
using System.Data;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Shipping : Window
    {
        private readonly int? _employeeId;

        // ==========================================
        // DataGrid 表示用
        // ==========================================
        private class ShippingRow
        {
            public int ShId { get; set; }
            public int OrId { get; set; }
            public int ClId { get; set; }
            public string ClientName { get; set; } = "";
            public int SoId { get; set; }
            public int? EmId { get; set; }
            public DateTime? ShFinishDate { get; set; }
            public int? ShStateFlag { get; set; }

            public string ShippingDateText
            {
                get
                {
                    return ShFinishDate.HasValue
                        ? ShFinishDate.Value.ToString(
                            "yyyy/MM/dd HH:mm:ss")
                        : "未設定";
                }
            }

            public string StatusText
            {
                get
                {
                    return ShStateFlag == 1
                        ? "確定済み"
                        : "未確定";
                }
            }
        }

        // ==========================================
        // Constructor
        // ==========================================
        public F_Shipping(int? employeeId = null)
        {
            InitializeComponent();
            _employeeId = employeeId;
        }

        // ==========================================
        // 画面起動
        // ==========================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            LoadShippingData();
        }

        // ==========================================
        // 出荷一覧表示
        // ==========================================
        private void LoadShippingData(
            int? shId = null,
            string clientName = "")
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query =
                    from sh in context.TShipments.AsNoTracking()
                    join cl in context.MClients.AsNoTracking()
                        on sh.ClId equals cl.ClId
                    where sh.ShFlag == 0
                    select new
                    {
                        sh.ShId,
                        sh.OrId,
                        sh.ClId,
                        ClientName = cl.ClName,
                        sh.SoId,
                        sh.EmId,
                        sh.ShFinishDate,
                        sh.ShStateFlag
                    };

                if (shId.HasValue)
                {
                    query = query.Where(
                        x => x.ShId == shId.Value);
                }

                if (!string.IsNullOrWhiteSpace(clientName))
                {
                    query = query.Where(
                        x => x.ClientName.Contains(clientName));
                }

                var shipments = query
                    .OrderByDescending(x => x.ShId)
                    .ToList();

                var data = shipments.Select(x =>
                    new ShippingRow
                    {
                        ShId = x.ShId,
                        OrId = x.OrId,
                        ClId = x.ClId,
                        ClientName = x.ClientName ?? "",
                        SoId = x.SoId,
                        EmId = x.EmId,
                        ShFinishDate = x.ShFinishDate,
                        ShStateFlag = x.ShStateFlag
                    })
                    .ToList();

                dgShipping.ItemsSource = data;
            }
            catch (Exception ex)
            {
                ShowError("出荷一覧取得エラー", ex);
            }
        }

        // ==========================================
        // 出荷検索
        // ==========================================
        private void btnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            int? shId = null;

            string idText = txtShID.Text.Trim();
            string clientName = txtClientName.Text.Trim();

            if (!string.IsNullOrWhiteSpace(idText))
            {
                if (!int.TryParse(idText, out int parsedId))
                {
                    MessageBox.Show(
                        "出荷IDは数字で入力してください。");
                    return;
                }

                shId = parsedId;
            }

            LoadShippingData(shId, clientName);

            if (dgShipping.Items.Count == 0)
            {
                MessageBox.Show(
                    "該当する出荷データがありません。");
            }
        }

        // ==========================================
        // 一覧表示
        // ==========================================
        private void btnReload_Click(
            object sender,
            RoutedEventArgs e)
        {
            txtShID.Clear();
            txtClientName.Clear();

            LoadShippingData();
        }

        // ==========================================
        // 出荷確定
        // ==========================================
        private void btnConfirm_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (dgShipping.SelectedItem
                is not ShippingRow selected)
            {
                MessageBox.Show(
                    "出荷データを選択してください。");
                return;
            }

            if (!_employeeId.HasValue)
            {
                MessageBox.Show(
                    "担当社員IDが設定されていません。");
                return;
            }

            if (MessageBox.Show(
                $"出荷ID {selected.ShId} を確定しますか？",
                "出荷確定",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                using var transaction =
                    context.Database.BeginTransaction(
                        IsolationLevel.Serializable);

                // 社員ID確認
                bool employeeExists =
                    context.MEmployees.Any(
                        e => e.EmId == _employeeId.Value);

                if (!employeeExists)
                {
                    MessageBox.Show(
                        $"社員ID {_employeeId.Value} は" +
                        "社員マスタに存在しません。",
                        "社員IDエラー");
                    return;
                }

                var shipment = context.TShipments
                    .Include(x => x.TShipmentDetails)
                    .FirstOrDefault(x =>
                        x.ShId == selected.ShId &&
                        x.ShFlag == 0);

                if (shipment == null)
                {
                    MessageBox.Show(
                        "出荷データが見つかりません。");
                    return;
                }

                if (shipment.ShStateFlag != 0)
                {
                    MessageBox.Show(
                        "この出荷は既に確定済みです。");
                    return;
                }

                var details =
                    shipment.TShipmentDetails.ToList();

                if (details.Count == 0)
                {
                    MessageBox.Show(
                        "出荷詳細がありません。");
                    return;
                }

                if (details.Any(d => d.ShQuantity <= 0))
                {
                    MessageBox.Show(
                        "出荷数量が正しくありません。");
                    return;
                }

                // 売上重複チェック
                var existingSale = context.TSales
                    .AsNoTracking()
                    .FirstOrDefault(s =>
                        s.OrId == shipment.OrId);

                if (existingSale != null)
                {
                    MessageBox.Show(
                        "この受注の売上データは既に存在します。\n" +
                        "受注ID: " + shipment.OrId +
                        "\n既存売上ID: " + existingSale.SaId +
                        "\n出荷状態は変更していません。",
                        "売上重複確認",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                // ==================================
                // 売上ヘッダー作成
                // ==================================
                var now = DateTime.Now;

                var sale = new TSale
                {
                    OrId = shipment.OrId,
                    ClId = shipment.ClId,
                    SoId = shipment.SoId,
                    EmId = _employeeId.Value,
                    SaDate = now,
                    SaFlag = 0,
                    SaHidden = ""
                };

                context.TSales.Add(sale);
                context.SaveChanges();

                // ==================================
                // 売上詳細作成
                // ==================================
                foreach (var detail in details)
                {
                    context.TSaleDetails.Add(
                        new TSaleDetail
                        {
                            SaId = sale.SaId,
                            PrId = detail.PrId,
                            SaQuantity = detail.ShQuantity
                        });
                }

                // ==================================
                // 出荷確定日時
                // ==================================
                shipment.ShStateFlag = 1;
                shipment.ShFinishDate = now;
                shipment.EmId = _employeeId.Value;

                context.SaveChanges();
                transaction.Commit();

                // ==================================
                // 完了メッセージ
                // ==================================
                MessageBox.Show(
                    "出荷確定が完了しました。\n" +
                    "出荷ID: " + shipment.ShId +
                    "\n出荷日時: " +
                    shipment.ShFinishDate?.ToString(
                        "yyyy/MM/dd HH:mm:ss") +
                    "\n売上ID: " + sale.SaId,
                    "完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                LoadShippingData();
            }
            catch (Exception ex)
            {
                ShowError("出荷確定エラー", ex);
            }
        }

        // ==========================================
        // 非表示
        // ==========================================
        private void btnHide_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (dgShipping.SelectedItem
                is not ShippingRow selected)
            {
                MessageBox.Show(
                    "出荷データを選択してください。");
                return;
            }

            if (MessageBox.Show(
                $"出荷ID {selected.ShId} を非表示にしますか？",
                "非表示確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                var shipment = context.TShipments
                    .FirstOrDefault(x =>
                        x.ShId == selected.ShId &&
                        x.ShFlag == 0);

                if (shipment == null)
                {
                    MessageBox.Show(
                        "出荷データが見つかりません。");
                    return;
                }

                shipment.ShFlag = 1;
                shipment.ShHidden = "非表示";

                context.SaveChanges();

                MessageBox.Show("非表示にしました。");
                LoadShippingData();
            }
            catch (Exception ex)
            {
                ShowError("非表示エラー", ex);
            }
        }


        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "出荷管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

        // ==========================================
        // エラー表示
        // ==========================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                title + ":\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
