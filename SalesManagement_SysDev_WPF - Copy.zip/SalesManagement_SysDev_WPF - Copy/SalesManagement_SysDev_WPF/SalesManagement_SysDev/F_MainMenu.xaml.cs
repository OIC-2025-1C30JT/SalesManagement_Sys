﻿
using System;
using System.Windows;
using System.Windows.Threading;

namespace SalesManagement_SysDev
{
    public partial class F_MainMenu : Window
    {
        private string userRole = "";

        // ログイン中の社員ID
        private int? _employeeId;

        // 時計
        private readonly DispatcherTimer timer = new DispatcherTimer();

        // デフォルトコンストラクター
        public F_MainMenu()
        {
            InitializeComponent();

            // ログイン情報から取得
            userRole = LoginSession.Role;

            // 社員IDを取得
            // 管理者など、社員IDがない場合は null
            if (int.TryParse(LoginSession.UserId, out int id))
            {
                _employeeId = id;
            }
            else
            {
                _employeeId = null;
            }
        }

        // Role のみ受け取る
        public F_MainMenu(string role) : this()
        {
            userRole = role;
        }

        // Role と社員IDを受け取る
        public F_MainMenu(string role, int employeeId) : this()
        {
            userRole = role;
            _employeeId = employeeId;
        }

        // 画面起動時
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // ログイン確認
            if (string.IsNullOrEmpty(LoginSession.Role))
            {
                MessageBox.Show(
                    "ログイン情報がありません。\nもう一度ログインしてください。",
                    "ログインエラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                Close();
                return;
            }

            // ログイン中のユーザー情報
            lblUser.Text = LoginSession.UserName + " さん";

            lblRole.Text =
                "権限：" + LoginSession.Role +
                "\nID：" + LoginSession.UserId;

            // 現在日時
            lblDate.Text =
                DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            // 時計を開始
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick -= Timer_Tick;
            timer.Tick += Timer_Tick;
            timer.Start();

            // 会社名
            lblCompany.Text = AppConfig.CompanyName;

            // システム管理は管理者のみ
            btnSystemAdmin.Visibility =
                LoginSession.IsAdministrator
                    ? Visibility.Visible
                    : Visibility.Collapsed;

            // 権限に応じたメニュー表示
            ApplyRole();
        }

        // 時計更新
        private void Timer_Tick(object sender, EventArgs e)
        {
            lblDate.Text =
                DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
        }

        // 権限設定
        private void ApplyRole()
        {
            // 一度すべて表示
            btnClient.Visibility = Visibility.Visible;
            btnEmployee.Visibility = Visibility.Visible;
            btnOrderEntry.Visibility = Visibility.Visible;
            btnOrder.Visibility = Visibility.Visible;
            btnReceiving.Visibility = Visibility.Visible;
            btnShipping.Visibility = Visibility.Visible;
            btnSales.Visibility = Visibility.Visible;
            btnProduct.Visibility = Visibility.Visible;
            btnStock.Visibility = Visibility.Visible;
            btnShipment.Visibility = Visibility.Visible;
            btnPurchase.Visibility = Visibility.Visible;
            btnArrival.Visibility = Visibility.Visible;

            // 管理者
            if (LoginSession.IsAdministrator ||
                userRole == "管理者")
            {
                return;
            }

            // 物流担当
            if (userRole == "物流担当")
            {
                btnClient.Visibility = Visibility.Collapsed;
                btnEmployee.Visibility = Visibility.Collapsed;
                btnOrderEntry.Visibility = Visibility.Collapsed;
                btnOrder.Visibility = Visibility.Collapsed;
                btnReceiving.Visibility = Visibility.Collapsed;
                btnShipping.Visibility = Visibility.Collapsed;
                btnSales.Visibility = Visibility.Collapsed;
            }

            // 営業担当
            else if (userRole == "営業担当")
            {
                btnProduct.Visibility = Visibility.Collapsed;
                btnStock.Visibility = Visibility.Collapsed;
                btnEmployee.Visibility = Visibility.Collapsed;
                btnShipment.Visibility = Visibility.Collapsed;
                btnPurchase.Visibility = Visibility.Collapsed;
                btnArrival.Visibility = Visibility.Collapsed;
            }
        }

        // システム管理
        private void btnSystemAdmin_Click(
            object sender, RoutedEventArgs e)
        {
            if (!LoginSession.IsAdministrator)
            {
                MessageBox.Show(
                    "管理者権限が必要です。",
                    "アクセス拒否",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }

            OpenWindow(new F_SystemAdmin());

            // 会社名を再取得
            lblCompany.Text = AppConfig.CompanyName;
        }

        // 受注管理
        private void btnOrderEntry_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Order());
        }

        // 注文管理
        private void btnOrder_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Chumon(_employeeId));
        }

        // 商品管理
        private void btnProduct_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Product());
        }

        // 顧客管理
        private void btnClient_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Client());
        }

        // 社員管理
        private void btnEmployee_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Employee());
        }

        // 在庫管理
        private void btnStock_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Stock());
        }

        // 売上管理
        private void btnSales_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Sale());
        }

        // 発注管理
        private void btnPurchase_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Hattyu());
        }

        // 入庫管理
        private void btnArrival_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Arrival());
        }

        // 出庫管理
        private void btnShipment_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Shipment(_employeeId));
        }

        // 入荷管理
        private void btnReceiving_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Receiving(_employeeId));
        }

        // 出荷管理
        private void btnShipping_Click(
            object sender, RoutedEventArgs e)
        {
            OpenWindow(new F_Shipping(_employeeId));
        }

        // 共通画面表示
        private void OpenWindow(Window frm)
        {
            frm.Owner = this;

            frm.WindowStartupLocation =
                WindowStartupLocation.CenterOwner;

            frm.WindowState = WindowState.Maximized;

            frm.ShowDialog();
        }

        // ログアウト

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
              "ログアウトしてもよろしいですか？\nログイン画面に戻ります。",
              "ログアウトの確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question,
                MessageBoxResult.No
            );

            if (result == MessageBoxResult.Yes)
            {
                timer.Stop();

                F_login login = new F_login();
                login.Show();

                Close();
            }
        }


        // ウィンドウ終了時
        protected override void OnClosed(EventArgs e)
        {
            timer.Stop();
            base.OnClosed(e);
        }
    }
}
