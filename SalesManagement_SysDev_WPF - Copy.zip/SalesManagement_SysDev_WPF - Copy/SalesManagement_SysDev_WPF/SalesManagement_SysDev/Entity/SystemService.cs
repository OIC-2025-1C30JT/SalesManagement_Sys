﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace SalesManagement_SysDev
{
    // 役職一覧
    public class PositionRow
    {
        public int PoId { get; set; }
        public string PoName { get; set; } = "";
        public int EmployeeCount { get; set; }
        public int PoFlag { get; set; }

        public string StateText =>
            PoFlag == 2 ? "非表示" : "有効";
    }

    // 営業所一覧
    public class OfficeRow
    {
        public int SoId { get; set; }
        public string SoName { get; set; } = "";
        public string SoPostal { get; set; } = "";
        public string SoAddress { get; set; } = "";
        public string SoPhone { get; set; } = "";
        public string SoFax { get; set; } = "";
        public int EmployeeCount { get; set; }
        public int ClientCount { get; set; }
        public int SoFlag { get; set; }

        public string StateText =>
            SoFlag == 2 ? "非表示" : "有効";
    }

    public class SystemService
    {
        // =====================================
        // 役職管理
        // =====================================

        public List<PositionRow> GetPositions()
        {
            using SalesManagementContext context =
                new SalesManagementContext();

            return context.MPositions
                .OrderBy(x => x.PoId)
                .Select(x => new PositionRow
                {
                    PoId = x.PoId,
                    PoName = x.PoName,
                    EmployeeCount =
                        x.MEmployees.Count(e => e.EmFlag == 0),
                    PoFlag = x.PoFlag
                })
                .ToList();
        }

        public string AddPosition(string name)
        {
            if (LoginSession.IsStandardPosition(name))
            {
                return "「管理」「物流」「営業」を含む名前は使えません";
            }

            using SalesManagementContext context =
                new SalesManagementContext();

            if (context.MPositions.Any(x => x.PoName == name))
            {
                return "同じ名前の役職が既にあります";
            }

            MPosition po = new MPosition
            {
                PoName = name,
                PoFlag = 0
            };

            context.MPositions.Add(po);
            context.SaveChanges();

            return "";
        }

        public string SetPositionHidden(int poId, bool hide)
        {
            using SalesManagementContext context =
                new SalesManagementContext();

            var po = context.MPositions
                .FirstOrDefault(x => x.PoId == poId);

            if (po == null)
            {
                return "役職が見つかりません";
            }

            if (hide)
            {
                if (po.PoFlag == 2)
                {
                    return "既に非表示になっています";
                }

                if (LoginSession.IsStandardPosition(po.PoName))
                {
                    return "標準の役職は非表示にできません";
                }

                int count = context.MEmployees.Count(
                    x => x.PoId == poId && x.EmFlag == 0);

                if (count > 0)
                {
                    return "この役職の社員が " + count +
                           " 名います。先に社員の役職を変更してください";
                }

                po.PoFlag = 2;
            }
            else
            {
                if (po.PoFlag == 0)
                {
                    return "既に表示されています";
                }

                po.PoFlag = 0;
            }

            context.SaveChanges();
            return "";
        }

        // =====================================
        // 営業所管理
        // =====================================

        public List<OfficeRow> GetOffices()
        {
            using SalesManagementContext context =
                new SalesManagementContext();

            return context.MSalesOffices
                .OrderBy(x => x.SoId)
                .Select(x => new OfficeRow
                {
                    SoId = x.SoId,
                    SoName = x.SoName,
                    SoPostal = x.SoPostal,
                    SoAddress = x.SoAddress,
                    SoPhone = x.SoPhone,
                    SoFax = x.SoFax,
                    EmployeeCount =
                        x.MEmployees.Count(e => e.EmFlag == 0),
                    ClientCount =
                        x.MClients.Count(c => c.ClFlag == 0),
                    SoFlag = x.SoFlag
                })
                .ToList();
        }

        public string AddOffice(MSalesOffice office)
        {
            using SalesManagementContext context =
                new SalesManagementContext();

            if (context.MSalesOffices.Any(
                x => x.SoName == office.SoName))
            {
                return "同じ名前の営業所が既にあります";
            }

            office.SoFlag = 0;

            context.MSalesOffices.Add(office);
            context.SaveChanges();

            return "";
        }

        public string SetOfficeHidden(int soId, bool hide)
        {
            using SalesManagementContext context =
                new SalesManagementContext();

            var so = context.MSalesOffices
                .FirstOrDefault(x => x.SoId == soId);

            if (so == null)
            {
                return "営業所が見つかりません";
            }

            if (hide)
            {
                if (so.SoFlag == 2)
                {
                    return "既に非表示になっています";
                }

                int emp = context.MEmployees.Count(
                    x => x.SoId == soId && x.EmFlag == 0);

                int cl = context.MClients.Count(
                    x => x.SoId == soId && x.ClFlag == 0);

                if (emp > 0 || cl > 0)
                {
                    return "この営業所には、社員が " + emp +
                           " 名、顧客が " + cl +
                           " 件います。\n先に社員・顧客の営業所を変更するか、非表示にしてください";
                }

                so.SoFlag = 2;
            }
            else
            {
                if (so.SoFlag == 0)
                {
                    return "既に表示されています";
                }

                so.SoFlag = 0;
            }

            context.SaveChanges();
            return "";
        }

        // =====================================
        // 社員一覧・権限設定
        // =====================================


        public List<EmployeeAdminRow> GetEmployees(string keyword)
        {
            using SalesManagementContext context =
                new SalesManagementContext();

            var query = context.MEmployees
                .Where(x => x.EmFlag == 0);

            // 社員ID・社員名で検索
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                keyword = keyword.Trim();

                if (int.TryParse(keyword, out int id))
                {
                    query = query.Where(x =>
                        x.EmId == id ||
                        x.EmName.Contains(keyword));
                }
                else
                {
                    query = query.Where(x =>
                        x.EmName.Contains(keyword));
                }
            }

            // 社員データを取得
            List<EmployeeAdminRow> list = query
                .OrderBy(x => x.EmId)
                .Select(x => new EmployeeAdminRow
                {
                    EmId = x.EmId,
                    EmName = x.EmName,
                    SoName = x.So.SoName,
                    PoName = x.Po.PoName
                })
                .ToList();

            // 社員ごとの権限を設定
            foreach (EmployeeAdminRow row in list)
            {
                // 役職から身分を判定
                row.RoleName =
                    LoginSession.GetRoleName(row.PoName);

                // リーダー判定
                row.IsLeader =
                    AppSettings.IsLeader(row.EmId);

                // 個別権限の有無
                row.HasPersonal =
                    AppSettings.GetEmployeePermissions(row.EmId)
                    != null;

                // 使えるモジュール名を作成
                List<string> moduleNames = new List<string>();

                foreach (string key in
                    ModulePermission.GetAllowedKeys(row.RoleName))
                {
                    moduleNames.Add(
                        ModulePermission.GetDisplayName(key));
                }

                row.AllowedModules =
                    string.Join("、", moduleNames);
            }

            return list;
        }

    }
}
