﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Product : Window
    {
        // =====================================
        // DataGrid Row
        // =====================================
        private class ProductRow
        {
            public int PrId { get; set; }
            public string PrName { get; set; }
            public decimal Price { get; set; }
            public int StockQuantity { get; set; }
            public int PrSafetyStock { get; set; }
            public int ScId { get; set; }
            public string PrModelNumber { get; set; }
            public string PrColor { get; set; }
            public DateTime? PrReleaseDate { get; set; }
            public int PrFlag { get; set; }
            public string PrHidden { get; set; }
        }

        // =====================================
        // Fields
        // =====================================
        private int? selectedProductId;

        private ProductRow originalProduct;

        private bool isLoading;
        private bool isRestoringSelection;
        private bool isSelectionChangePending;
        private bool isRevertingCheckbox;
        private bool allowClose;

        // =====================================
        // Constructor
        // =====================================
        public F_Product()
        {
            InitializeComponent();
        }

        // =====================================
        // Window Loaded
        // =====================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            ClearInputFields();
            LoadProductData();
        }

        // =====================================
        // Load Product Data
        // =====================================
        private void LoadProductData()
        {
            try
            {
                isLoading = true;

                using SalesManagementContext context =
                    new SalesManagementContext();

                var query = context.MProducts
                    .AsNoTracking()
                    .AsQueryable();

                if (chkShowHidden.IsChecked != true)
                {
                    query = query.Where(p => p.PrFlag == 0);
                }

                List<ProductRow> products = query
                    .Select(p => new ProductRow
                    {
                        PrId = p.PrId,
                        PrName = p.PrName,
                        Price = p.Price,
                        PrSafetyStock = p.PrSafetyStock,
                        ScId = p.ScId,
                        PrModelNumber = p.PrModelNumber,
                        PrColor = p.PrColor,
                        PrReleaseDate = p.PrReleaseDate,
                        PrFlag = p.PrFlag,
                        PrHidden = p.PrHidden,

                        StockQuantity = context.TStocks
                            .Where(s =>
                                s.PrId == p.PrId &&
                                s.StFlag == 0)
                            .Select(s => (int?)s.StQuantity)
                            .Sum() ?? 0
                    })
                    .OrderBy(p => p.PrId)
                    .ToList();

                dgProduct.ItemsSource = products;

                lblCount.Text =
                    $"表示件数：{products.Count} 件";
            }
            catch (Exception ex)
            {
                ShowError("一覧表示エラー", ex);
            }
            finally
            {
                isLoading = false;
            }
        }

        // =====================================
        // Unsaved Changes
        // =====================================
        private bool HasUnsavedChanges()
        {
            if (isLoading)
            {
                return false;
            }

            if (originalProduct == null)
            {
                return
                    !string.IsNullOrWhiteSpace(txtPrName.Text) ||
                    !string.IsNullOrWhiteSpace(txtPrice.Text) ||
                    !string.IsNullOrWhiteSpace(txtSafetyStock.Text) ||
                    !string.IsNullOrWhiteSpace(txtScId.Text) ||
                    !string.IsNullOrWhiteSpace(txtModelNumber.Text) ||
                    !string.IsNullOrWhiteSpace(txtColor.Text) ||
                    dpReleaseDate.SelectedDate.HasValue ||
                    !string.IsNullOrWhiteSpace(
                        txtHiddenReason.Text);
            }

            return
                txtPrName.Text.Trim() !=
                    (originalProduct.PrName ?? "") ||

                txtPrice.Text.Trim() !=
                    originalProduct.Price.ToString(
                        CultureInfo.CurrentCulture) ||

                txtSafetyStock.Text.Trim() !=
                    originalProduct.PrSafetyStock.ToString() ||

                txtScId.Text.Trim() !=
                    originalProduct.ScId.ToString() ||

                txtModelNumber.Text.Trim() !=
                    (originalProduct.PrModelNumber ?? "") ||

                txtColor.Text.Trim() !=
                    (originalProduct.PrColor ?? "") ||

                dpReleaseDate.SelectedDate !=
                    originalProduct.PrReleaseDate ||

                GetSelectedFlag() !=
                    originalProduct.PrFlag ||

                txtHiddenReason.Text.Trim() !=
                    (originalProduct.PrHidden ?? "");
        }

        // =====================================
        // Warning
        // =====================================
        private bool ConfirmDiscardChanges()
        {
            if (!HasUnsavedChanges())
            {
                return true;
            }

            MessageBoxResult result = MessageBox.Show(
                "変更内容が保存されていません。\n" +
                "保存せずに移動しますか？",
                "未保存データの警告",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            return result == MessageBoxResult.Yes;
        }

        // =====================================
        // DataGrid Selection
        // =====================================
        private void dgProduct_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (isLoading ||
                isRestoringSelection ||
                isSelectionChangePending)
            {
                return;
            }

            if (dgProduct.SelectedItem is not ProductRow product)
            {
                return;
            }

            if (selectedProductId.HasValue &&
                selectedProductId.Value == product.PrId)
            {
                return;
            }

            if (HasUnsavedChanges())
            {
                isSelectionChangePending = true;

                MessageBoxResult result;

                try
                {
                    result = MessageBox.Show(
                        "変更内容が保存されていません。\n" +
                        "保存せずに移動しますか？",
                        "未保存データの警告",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning);
                }
                finally
                {
                    isSelectionChangePending = false;
                }

                if (result == MessageBoxResult.No)
                {
                    isRestoringSelection = true;

                    try
                    {
                        ProductRow previous = null;

                        if (selectedProductId.HasValue)
                        {
                            previous = dgProduct.Items
                                .OfType<ProductRow>()
                                .FirstOrDefault(x =>
                                    x.PrId ==
                                    selectedProductId.Value);
                        }

                        dgProduct.SelectedItem = previous;

                        if (previous != null)
                        {
                            dgProduct.ScrollIntoView(previous);
                        }
                    }
                    finally
                    {
                        isRestoringSelection = false;
                    }

                    return;
                }
            }

            LoadSelectedProduct(product);
        }

        // =====================================
        // Load Selected Product
        // =====================================
        private void LoadSelectedProduct(
            ProductRow product)
        {
            isLoading = true;

            try
            {
                selectedProductId = product.PrId;

                originalProduct = new ProductRow
                {
                    PrId = product.PrId,
                    PrName = product.PrName,
                    Price = product.Price,
                    StockQuantity = product.StockQuantity,
                    PrSafetyStock = product.PrSafetyStock,
                    ScId = product.ScId,
                    PrModelNumber = product.PrModelNumber,
                    PrColor = product.PrColor,
                    PrReleaseDate = product.PrReleaseDate,
                    PrFlag = product.PrFlag,
                    PrHidden = product.PrHidden
                };

                txtPrID.Text = product.PrId.ToString();
                txtPrName.Text = product.PrName ?? "";
                txtPrice.Text = product.Price.ToString(
                    CultureInfo.CurrentCulture);

                txtStock.Text =
                    product.StockQuantity.ToString();

                txtSafetyStock.Text =
                    product.PrSafetyStock.ToString();

                txtScId.Text = product.ScId.ToString();

                txtModelNumber.Text =
                    product.PrModelNumber ?? "";

                txtColor.Text = product.PrColor ?? "";

                dpReleaseDate.SelectedDate =
                    product.PrReleaseDate;

                cmbPrFlag.SelectedIndex =
                    product.PrFlag == 2 ? 1 : 0;

                txtHiddenReason.Text =
                    product.PrHidden ?? "";

                btnInsert.IsEnabled = false;
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled =
                    product.PrFlag == 0;

                UpdateHiddenReasonState();
            }
            finally
            {
                isLoading = false;
            }
        }

        // =====================================
        // Selected Flag
        // =====================================
        private int GetSelectedFlag()
        {
            if (cmbPrFlag.SelectedItem
                is ComboBoxItem item &&
                int.TryParse(
                    item.Tag?.ToString(),
                    out int flag))
            {
                return flag;
            }

            return 0;
        }

        // =====================================
        // Hidden Reason State
        // =====================================
        private void cmbPrFlag_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            UpdateHiddenReasonState();
        }

        private void UpdateHiddenReasonState()
        {
            if (txtHiddenReason == null ||
                cmbPrFlag == null)
            {
                return;
            }

            txtHiddenReason.IsEnabled =
                GetSelectedFlag() == 2;
        }

        // =====================================
        // Validate
        // =====================================
        private bool ValidateProductInput(
            out decimal price,
            out int safetyStock,
            out int categoryId)
        {
            price = 0;
            safetyStock = 0;
            categoryId = 0;

            if (string.IsNullOrWhiteSpace(txtPrName.Text))
            {
                MessageBox.Show(
                    "商品名を入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtPrName.Focus();
                return false;
            }

            if (!decimal.TryParse(
                txtPrice.Text,
                out price) || price < 0)
            {
                MessageBox.Show(
                    "価格は0以上の数値で入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtPrice.Focus();
                return false;
            }

            if (!int.TryParse(
                txtSafetyStock.Text,
                out safetyStock) || safetyStock < 0)
            {
                MessageBox.Show(
                    "安全在庫数は0以上の整数で入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtSafetyStock.Focus();
                return false;
            }

            if (!int.TryParse(
                txtScId.Text,
                out categoryId) || categoryId <= 0)
            {
                MessageBox.Show(
                    "小分類IDは1以上の整数で入力してください。",
                    "入力エラー",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtScId.Focus();
                return false;
            }

            return true;
        }

        // =====================================
        // Insert
        // =====================================
        private void btnInsert_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (selectedProductId.HasValue)
            {
                MessageBox.Show(
                    "新規登録する場合はクリアしてください。");
                return;
            }

            if (!ValidateProductInput(
                out decimal price,
                out int safetyStock,
                out int categoryId))
            {
                return;
            }

            if (MessageBox.Show(
                "新しい商品を登録しますか？",
                "登録確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using SalesManagementContext context =
                    new SalesManagementContext();

                using var transaction =
                    context.Database.BeginTransaction();

                MProduct product = new MProduct
                {
                    PrName = txtPrName.Text.Trim(),
                    Price = price,
                    PrSafetyStock = safetyStock,
                    ScId = categoryId,
                    PrModelNumber =
                        txtModelNumber.Text.Trim(),
                    PrColor = txtColor.Text.Trim(),
                    PrReleaseDate =
                        dpReleaseDate.SelectedDate
                        ?? DateTime.Today,
                    PrFlag = 0,
                    PrHidden = "",
                    MaId = 1
                };

                context.MProducts.Add(product);
                context.SaveChanges();

                TStock stock = new TStock
                {
                    PrId = product.PrId,
                    StQuantity = 0,
                    StFlag = 0
                };

                context.TStocks.Add(stock);
                context.SaveChanges();

                transaction.Commit();

                ClearInputFields();
                LoadProductData();

                MessageBox.Show(
                    "商品を登録しました。",
                    "登録完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("登録エラー", ex);
            }
        }

        // =====================================
        // Update
        // =====================================
        private void btnUpdate_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedProductId.HasValue)
            {
                MessageBox.Show(
                    "更新する商品を選択してください。");
                return;
            }

            if (!ValidateProductInput(
                out decimal price,
                out int safetyStock,
                out int categoryId))
            {
                return;
            }

            if (MessageBox.Show(
                "選択した商品情報を更新しますか？",
                "更新確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using SalesManagementContext context =
                    new SalesManagementContext();

                MProduct product = context.MProducts
                    .FirstOrDefault(p =>
                        p.PrId == selectedProductId.Value);

                if (product == null)
                {
                    MessageBox.Show(
                        "商品が見つかりません。");
                    return;
                }

                product.PrName = txtPrName.Text.Trim();
                product.Price = price;
                product.PrSafetyStock = safetyStock;
                product.ScId = categoryId;
                product.PrModelNumber =
                    txtModelNumber.Text.Trim();
                product.PrColor = txtColor.Text.Trim();

                product.PrReleaseDate =
                    dpReleaseDate.SelectedDate
                    ?? DateTime.Today;

                product.PrFlag = GetSelectedFlag();

                product.PrHidden =
                    product.PrFlag == 0
                    ? ""
                    : txtHiddenReason.Text.Trim();

                context.SaveChanges();

                ClearInputFields();
                LoadProductData();

                MessageBox.Show(
                    "商品情報を更新しました。",
                    "更新完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("更新エラー", ex);
            }
        }

        // =====================================
        // Hide
        // =====================================
        private void btnDelete_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!selectedProductId.HasValue)
            {
                MessageBox.Show(
                    "非表示にする商品を選択してください。");
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                return;
            }

            if (MessageBox.Show(
                "選択した商品を非表示にしますか？",
                "非表示確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using SalesManagementContext context =
                    new SalesManagementContext();

                MProduct product = context.MProducts
                    .FirstOrDefault(p =>
                        p.PrId == selectedProductId.Value);

                if (product == null)
                {
                    MessageBox.Show(
                        "商品が見つかりません。");
                    return;
                }

                if (product.PrFlag == 2)
                {
                    MessageBox.Show(
                        "この商品は既に非表示です。");
                    return;
                }

                product.PrFlag = 2;
                product.PrHidden =
                    txtHiddenReason.Text.Trim();

                context.SaveChanges();

                ClearInputFields();
                LoadProductData();

                MessageBox.Show(
                    "商品を非表示にしました。",
                    "非表示完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("非表示エラー", ex);
            }
        }

        // =====================================
        // Clear
        // =====================================
        private void btnClear_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            ClearInputFields();
        }

        private void ClearInputFields()
        {
            isLoading = true;

            try
            {
                dgProduct.SelectedItem = null;

                selectedProductId = null;
                originalProduct = null;

                txtPrID.Clear();
                txtPrName.Clear();
                txtPrice.Clear();
                txtStock.Clear();
                txtSafetyStock.Clear();
                txtScId.Clear();
                txtModelNumber.Clear();
                txtColor.Clear();

                dpReleaseDate.SelectedDate = null;
                cmbPrFlag.SelectedIndex = 0;
                txtHiddenReason.Clear();

                btnInsert.IsEnabled = true;
                btnUpdate.IsEnabled = false;
                btnDelete.IsEnabled = false;

                UpdateHiddenReasonState();

                txtPrName.Focus();
            }
            finally
            {
                isLoading = false;
            }
        }

        // =====================================
        // Show All
        // =====================================
        private void btnAll_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            ClearInputFields();
            LoadProductData();
        }

        // =====================================
        // Show Hidden
        // =====================================
        private void chkShowHidden_Changed(
            object sender,
            RoutedEventArgs e)
        {
            if (!IsLoaded || isRevertingCheckbox)
            {
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                isRevertingCheckbox = true;

                try
                {
                    chkShowHidden.IsChecked =
                        chkShowHidden.IsChecked != true;
                }
                finally
                {
                    isRevertingCheckbox = false;
                }

                return;
            }

            ClearInputFields();
            LoadProductData();
        }

        // =====================================
        // Close
        // =====================================
        private void btnClose_Click(
            object sender,
            RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Closing(
            object sender,
            CancelEventArgs e)
        {
            if (allowClose)
            {
                return;
            }

            if (!ConfirmDiscardChanges())
            {
                e.Cancel = true;
                return;
            }

            if (MessageBox.Show(
                "商品管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                e.Cancel = true;
                return;
            }

            allowClose = true;
        }

        // =====================================
        // Error
        // =====================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                ex.GetBaseException().Message,
                title,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
