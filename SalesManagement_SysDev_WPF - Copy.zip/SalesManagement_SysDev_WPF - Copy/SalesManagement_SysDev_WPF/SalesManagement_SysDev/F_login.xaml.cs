using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System.Windows;

namespace SalesManagement_SysDev
{
    public partial class F_login : Window
    {
        private bool goingToMenu = false;

        private bool isPasswordVisible = false;
        private bool isUpdatingPassword = false;

        // パスワード表示・非表示
        private void btnShowPassword_Click(
            object sender, RoutedEventArgs e)
        {
            isPasswordVisible = !isPasswordVisible;

            if (isPasswordVisible)
            {
                txtPasswordVisible.Text = txtPassword.Password;
                txtPassword.Visibility = Visibility.Collapsed;
                txtPasswordVisible.Visibility = Visibility.Visible;
                btnShowPassword.Content = "🙈";
            }
            else
            {
                txtPassword.Password = txtPasswordVisible.Text;
                txtPasswordVisible.Visibility = Visibility.Collapsed;
                txtPassword.Visibility = Visibility.Visible;
                btnShowPassword.Content = "👁";
            }
        }

        // PasswordBox の変更
        private void txtPassword_PasswordChanged(
            object sender, RoutedEventArgs e)
        {
            if (isUpdatingPassword) return;

            isUpdatingPassword = true;
            try
            {
                txtPasswordVisible.Text = txtPassword.Password;
            }
            finally
            {
                isUpdatingPassword = false;
            }
        }

        // TextBox の変更
        private void txtPasswordVisible_TextChanged(
            object sender,
            System.Windows.Controls.TextChangedEventArgs e)
        {
            if (isUpdatingPassword) return;

            isUpdatingPassword = true;
            try
            {
                txtPassword.Password = txtPasswordVisible.Text;
            }
            finally
            {
                isUpdatingPassword = false;
            }
        }

        public F_login()
        {
            InitializeComponent();
            this.Title = "販売管理システム - " + AppSettings.CompanyName;

        }

        // ID 输入变化时，判断是否显示管理者专用按钮
        private void txtEmID_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            // 窗口初始化时控件可能还没创建好，先判断
            if (panelAdminButtons == null) return;

            bool isAdminId = string.Equals(txtEmID.Text.Trim(), AppConfig.AdminId,
                                           StringComparison.OrdinalIgnoreCase);

            panelAdminButtons.Visibility = isAdminId ? Visibility.Visible : Visibility.Collapsed;
        }

        // ログイン機能 + ログイン判定機能
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string id = txtEmID.Text.Trim();
            string password = txtPassword.Password;

            if (id == "")
            {
                MessageBox.Show("社員IDを入力してください");
                return;
            }
            if (password == "")
            {
                MessageBox.Show("パスワードを入力してください");
                return;
            }

            // 锁定检查
            int remain;
            if (LoginLockManager.IsLocked(id, out remain))
            {
                MessageBox.Show("アカウントがロックされています。\nあと約 " + remain + " 分後に再度お試しください。");
                return;
            }

            bool success;
            if (string.Equals(id, AppConfig.AdminId, StringComparison.OrdinalIgnoreCase))
            {
                success = LoginAsAdministrator(password);
            }
            else
            {
                // 数字以外的 ID 视为未定义 ID
                int empid;
                if (int.TryParse(id, out empid))
                {
                    success = LoginAsEmployee(empid, password);
                }
                else
                {
                    success = false;
                }
            }

            if (success)
            {
                LoginLockManager.Reset(id);

                goingToMenu = true;          // 先做标记，再关闭登录窗口

                F_MainMenu fm = new F_MainMenu();
                fm.Show();
                this.Close();
            }
            else
            {
                bool locked = LoginLockManager.RecordFail(id);
                if (locked)
                {
                    MessageBox.Show("パスワードを5回連続で間違えました。\nアカウントを15分間ロックします。");
                }
                else
                {
                    MessageBox.Show("ID または Password が違います");
                }
                txtPassword.Clear();
            }
        }

        // administrator：不查数据库（数据库未生成时也要能登录）
        private bool LoginAsAdministrator(string password)
        {
            if (password != AppConfig.AdminPassword)
            {
                return false;
            }

            LoginSession.Set(AppConfig.AdminId, AppConfig.AdminName, LoginSession.RoleAdmin, 0, 0);
            MessageBox.Show(AppConfig.AdminName + " さん、ようこそ");
            return true;
        }

        // 普通社员：照合社員表，用役職名判断身份
        private bool LoginAsEmployee(int empid, string password)
        {
            try
            {
                using SalesManagementContext context = new SalesManagementContext();

                // EmFlag == 0 才是有效社员（2 为非表示）
                var employee = context.MEmployees
                                      .Include(x => x.Po)
                                      .FirstOrDefault(x => x.EmId == empid &&
                                                           x.EmPassword == password &&
                                                           x.EmFlag == 0);
                if (employee == null)
                {
                    return false;
                }

                // 根据役職名判断身份（样例数据：管理者／営業／物流）
                // 役職が非表示になっている社員はログインできない
                if (employee.Po.PoFlag != 0)
                {
                    return false;
                }

                // 役職名から身分を決める（標準の役職は 管理者／物流担当／営業担当、追加した役職は役職名）
                string role = LoginSession.GetRoleName(employee.Po.PoName);

                LoginSession.Set(empid.ToString(), employee.EmName, role, employee.EmId, employee.SoId);
                MessageBox.Show(employee.EmName + " さん、ようこそ");
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("データベースに接続できません。\n" +
                                "管理者でログインし、データベースを生成してください。\n\n" + ex.Message);
                return false;
            }
        }

        private void btnForgotPassword_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("パスワードを忘れた場合は、管理者にお問い合わせください。\n" +
                            "（管理者が社員管理画面でパスワードを再設定します）");
        }

        private void btnPasswordChange_Click(object sender, RoutedEventArgs e)
        {
            F_PasswordChange win = new F_PasswordChange(txtEmID.Text.Trim());
            win.Owner = this;
            win.ShowDialog();
            txtPassword.Clear();
        }

        // 登录窗口关闭时：不是为了进入 Portal 的话，就退出程序
        private void Window_Closed(object sender, EventArgs e)
        {
            if (!goingToMenu)
            {
                Application.Current.Shutdown();
            }
        }
        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            
            Application.Current.Shutdown();
        }

        private void btn_CleateDabase_Click(object sender, RoutedEventArgs e)
        {
            using SalesManagementContext context = new SalesManagementContext();

            context.Database.EnsureCreated();
            InsertDefaultPositions(context);

            MessageBox.Show("テーブル作成完了");
        }

        private void btn_InsertSampleData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using SalesManagementContext context = new SalesManagementContext();

                // ===== 重複登録の防止 =====
                if (context.MMakers.Any() || context.MSalesOffices.Any() ||
                    context.MClients.Any() || context.MProducts.Any())
                {
                    MessageBox.Show("サンプルデータは既に登録されています");
                    return;
                }
                if (context.MPositions.Count() < 3)
                {
                    MessageBox.Show("先に「データベース生成」を実行してください");
                    return;
                }

                // 途中でエラーが出たら、すべて取り消す
                using var tran = context.Database.BeginTransaction();

                List<MPosition> po = context.MPositions.OrderBy(x => x.PoId).ToList();

                // ---------- メーカー ----------
                List<MMaker> ma = new List<MMaker>();
                ma.Add(NewMaker("Aメーカ", "大阪"));
                ma.Add(NewMaker("Bメーカ", "京都"));
                ma.Add(NewMaker("Cメーカ", "和歌山"));
                ma.Add(NewMaker("Dメーカ", "滋賀"));
                context.MMakers.AddRange(ma);
                context.SaveChanges();

                // ---------- 営業所 ----------
                List<MSalesOffice> so = new List<MSalesOffice>();
                so.Add(NewOffice("北大阪営業所", "大阪府吹田市寿町3-4-40", "06-7011-6123", "5600046", "06-6562-2740"));
                so.Add(NewOffice("兵庫営業所", "兵庫県姫路市東辻井2-5-20", "079-669-4326", "6700994", "079-669-4327"));
                so.Add(NewOffice("鹿営業所", "奈良県生駒郡三郷町勢野8-7-50", "0745-99-0084", "6360814", "0746-0-1160"));
                so.Add(NewOffice("京都営業所", "京都府京都市山科区東野南井ノ上町10-3-7", "077-672-6006", "6078143", "0771-85-2574"));
                so.Add(NewOffice("和歌山営業所", "和歌山県和歌山市柳丁4-19", "073-887-1927", "6408336", "0735-78-4874"));
                context.MSalesOffices.AddRange(so);
                context.SaveChanges();

                // ---------- 顧客 ----------
                List<MClient> cl = new List<MClient>();
                cl.Add(NewClient("上村電機", "京都府京都市伏見区塩屋町3-9-95", "077-672-6006", "6128046", "077-581-0164", so[3]));
                cl.Add(NewClient("萬田金融", "大阪府大阪市西区北堀江1丁目22-3", "06-8757-6267", "5500014", "06-8757-6267", so[0]));
                cl.Add(NewClient("宝田電機", "大阪府大阪市中央区和泉町2-5-46", "06-1423-1895", "5720806", "06-1374-4358", so[0]));
                cl.Add(NewClient("INATUGI", "大阪府茨木市横江2-5-60", "072-02-5171", "5670044", "072-018-0116", so[0]));
                cl.Add(NewClient("水野電機", "大阪府豊中市末広町2-6-13", "06-2096-0974", "5600024", "06-2434-2434", so[1]));
                cl.Add(NewClient("ショップ赤川", "大阪府大阪市天王寺区上本町", "090-1111-1111", "5430001", "06-1111-1111", so[0]));
                cl.Add(NewClient("成田", "奈良県御所市船路2-8-87", "0746-0-1160", "6392268", "0746-0-1160", so[2]));
                context.MClients.AddRange(cl);
                context.SaveChanges();

                // ---------- 社員（po[0]=管理者、po[1]=営業、po[2]=物流） ----------
                Dictionary<int, MEmployee> em = new Dictionary<int, MEmployee>();
                em.Add(116, NewEmployee(116, "坂口郁美", new DateTime(1980, 6, 17), "0116", "06-6813-5485", so[1], po[2]));
                em.Add(310, NewEmployee(310, "高谷春男", new DateTime(1973, 3, 21), "0310", "06-6356-8742", so[0], po[1]));
                em.Add(1002, NewEmployee(1002, "日下部俊夫", new DateTime(1990, 9, 4), "1002", "06-6579-0622", so[0], po[1]));
                em.Add(1007, NewEmployee(1007, "岸本芽生", new DateTime(1997, 2, 4), "1007", "075-425-3371", so[2], po[1]));
                em.Add(1111, NewEmployee(1111, "奥村敦彦", new DateTime(1985, 3, 17), "999", "079-145-6121", so[3], po[2]));
                em.Add(1208, NewEmployee(1208, "渋谷秋昴", new DateTime(1994, 1, 31), "1208", "0790-68-8043", so[4], po[1]));
                em.Add(1227, NewEmployee(1227, "生田徳次郎", new DateTime(1964, 3, 20), "AA22", "06-3021-1630", so[0], po[0]));
                context.MEmployees.AddRange(em.Values);
                context.SaveChanges();

                // ---------- 大分類 ----------
                List<MMajorClassification> mc = new List<MMajorClassification>();
                mc.Add(new MMajorClassification() { McName = "テレビ・レコーダー", McFlag = 0 });
                mc.Add(new MMajorClassification() { McName = "エアコン・冷蔵庫・洗濯機", McFlag = 0 });
                mc.Add(new MMajorClassification() { McName = "オーディオ・イヤホン・ヘッドホン", McFlag = 0 });
                mc.Add(new MMajorClassification() { McName = "携帯電話・スマートフォン", McFlag = 0 });
                context.MMajorClassifications.AddRange(mc);
                context.SaveChanges();

                // ---------- 小分類 ----------
                List<MSmallClassification> sc = new List<MSmallClassification>();
                sc.Add(new MSmallClassification() { Mc = mc[0], ScName = "テレビ", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[0], ScName = "レコーダー", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[1], ScName = "エアコン", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[1], ScName = "冷蔵庫", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[1], ScName = "洗濯機", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[2], ScName = "オーディオ", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[2], ScName = "イヤホン", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[2], ScName = "ヘッドホン", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[3], ScName = "携帯電話", ScFlag = 0 });
                sc.Add(new MSmallClassification() { Mc = mc[3], ScName = "スマートフォン", ScFlag = 0 });
                context.MSmallClassifications.AddRange(sc);
                context.SaveChanges();

                // ---------- 商品 ----------
                List<MProduct> pr = new List<MProduct>();
                pr.Add(NewProduct(ma[0], sc[0], "テレビA", 100000, 100, "黒", new DateTime(2019, 5, 1)));
                pr.Add(NewProduct(ma[0], sc[0], "テレビB", 98000, 100, "黒", new DateTime(2019, 5, 10)));
                pr.Add(NewProduct(ma[0], sc[1], "レコーダーA", 5000, 50, "黒", new DateTime(2019, 10, 1)));
                pr.Add(NewProduct(ma[1], sc[2], "エアコンA", 160000, 50, "白", new DateTime(2020, 10, 1)));
                pr.Add(NewProduct(ma[1], sc[3], "冷蔵庫A", 200000, 50, "白", new DateTime(2020, 1, 1)));
                pr.Add(NewProduct(ma[1], sc[4], "洗濯機A", 150000, 50, "白", new DateTime(2019, 3, 1)));
                pr.Add(NewProduct(ma[2], sc[5], "オーディオA", 6000, 10, "黒", new DateTime(2020, 8, 1)));
                pr.Add(NewProduct(ma[2], sc[6], "イヤホンA", 5000, 100, "赤", new DateTime(2019, 5, 1)));
                pr.Add(NewProduct(ma[3], sc[8], "iphone8", 78800, 50, "ゴールド", new DateTime(2017, 9, 22)));
                pr.Add(NewProduct(ma[3], sc[9], "スマートフォンA", 30000, 50, "シルバー", new DateTime(2019, 5, 1)));
                pr.Add(NewProduct(ma[3], sc[9], "スマートフォンB", 40000, 50, "黒", new DateTime(2020, 11, 1)));
                context.MProducts.AddRange(pr);
                context.SaveChanges();

                // ---------- 在庫（サンプルは一部の商品だけ） ----------
                List<TStock> st = new List<TStock>();
                st.Add(new TStock() { Pr = pr[0], StQuantity = 100, StFlag = 0 });
                st.Add(new TStock() { Pr = pr[1], StQuantity = 120, StFlag = 0 });
                st.Add(new TStock() { Pr = pr[2], StQuantity = 199, StFlag = 0 });
                st.Add(new TStock() { Pr = pr[3], StQuantity = 50, StFlag = 0 });
                st.Add(new TStock() { Pr = pr[4], StQuantity = 60, StFlag = 0 });
                st.Add(new TStock() { Pr = pr[5], StQuantity = 32, StFlag = 0 });
                st.Add(new TStock() { Pr = pr[9], StQuantity = 240, StFlag = 0 });
                context.TStocks.AddRange(st);
                context.SaveChanges();

                // ---------- 受注 ----------
                List<TOrder> or = new List<TOrder>();
                or.Add(new TOrder
                {
                    So = so[0],
                    Em = em[310],
                    Cl = cl[1],
                    ClCharge = "萬田銀次郎",
                    OrDate = new DateTime(2020, 12, 10),
                    OrStateFlag = 1,
                    OrFlag = 0
                });
                or.Add(new TOrder
                {
                    So = so[1],
                    Em = em[116],
                    Cl = cl[4],
                    ClCharge = "水野勝成",
                    OrDate = new DateTime(2021, 1, 5),
                    OrStateFlag = 0,
                    OrFlag = 0
                });
                context.TOrders.AddRange(or);
                context.SaveChanges();

                // ---------- 受注詳細 ----------
                List<TOrderDetail> ord = new List<TOrderDetail>();
                ord.Add(new TOrderDetail() { Or = or[0], Pr = pr[2], OrQuantity = 40, OrTotalPrice = 200000 });
                ord.Add(new TOrderDetail() { Or = or[0], Pr = pr[9], OrQuantity = 30, OrTotalPrice = 900000 });
                ord.Add(new TOrderDetail() { Or = or[1], Pr = pr[3], OrQuantity = 20, OrTotalPrice = 3200000 });
                ord.Add(new TOrderDetail() { Or = or[1], Pr = pr[4], OrQuantity = 15, OrTotalPrice = 3000000 });
                ord.Add(new TOrderDetail() { Or = or[1], Pr = pr[5], OrQuantity = 15, OrTotalPrice = 2250000 });
                context.TOrderDetails.AddRange(ord);
                context.SaveChanges();

                // ---------- 注文・注文詳細（受注1が確定済みという想定） ----------
                List<TChumon> ch = new List<TChumon>();
                ch.Add(new TChumon()
                {
                    So = so[0],
                    Em = em[1002],
                    Cl = cl[1],
                    Or = or[0],
                    ChDate = new DateTime(2020, 12, 11),
                    ChStateFlag = 1,
                    ChFlag = 0
                });
                context.TChumons.AddRange(ch);
                context.SaveChanges();

                List<TChumonDetail> chd = new List<TChumonDetail>();
                chd.Add(new TChumonDetail() { Ch = ch[0], Pr = pr[2], ChQuantity = 40 });
                chd.Add(new TChumonDetail() { Ch = ch[0], Pr = pr[9], ChQuantity = 30 });
                context.TChumonDetails.AddRange(chd);
                context.SaveChanges();

                // ---------- 出庫・出庫詳細 ----------
                List<TSyukko> sy = new List<TSyukko>();
                sy.Add(new TSyukko() { Cl = cl[1], So = so[0], Or = or[0], SyStateFlag = 0, SyFlag = 0 });
                context.TSyukkos.AddRange(sy);
                context.SaveChanges();

                List<TSyukkoDetail> syd = new List<TSyukkoDetail>();
                syd.Add(new TSyukkoDetail() { Sy = sy[0], Pr = pr[2], SyQuantity = 40 });
                syd.Add(new TSyukkoDetail() { Sy = sy[0], Pr = pr[9], SyQuantity = 30 });
                context.TSyukkoDetails.AddRange(syd);
                context.SaveChanges();

                // すべて成功したので確定
                tran.Commit();

                // 登録件数を表示（0 件の表があれば、登録できていない）
                MessageBox.Show("サンプルデータ登録完了\n\n" +
                                "営業所：" + context.MSalesOffices.Count() + " 件\n" +
                                "メーカー：" + context.MMakers.Count() + " 件\n" +
                                "顧客：" + context.MClients.Count() + " 件\n" +
                                "社員：" + context.MEmployees.Count() + " 件\n" +
                                "商品：" + context.MProducts.Count() + " 件\n" +
                                "在庫：" + context.TStocks.Count() + " 件\n" +
                                "受注：" + context.TOrders.Count() + " 件\n" +
                                "注文：" + context.TChumons.Count() + " 件\n" +
                                "出庫：" + context.TSyukkos.Count() + " 件");
            }
            catch (Exception ex)
            {
                MessageBox.Show("サンプルデータの登録に失敗しました。\n" +
                                "（途中までの登録は取り消されました）\n\n" + ex.Message);
            }
        }

        // ---------- サンプル登録用の補助メソッド ----------

        private MMaker NewMaker(string name, string address)
        {
            MMaker m = new MMaker();
            m.MaName = name;
            m.MaAddress = address;
            m.MaPhone = "000-0000-0000";
            m.MaPostal = "0000000";
            m.MaFax = "000-0000-0000";
            m.MaFlag = 0;
            return m;
        }

        private MSalesOffice NewOffice(string name, string address, string phone, string postal, string fax)
        {
            MSalesOffice o = new MSalesOffice();
            o.SoName = name;
            o.SoAddress = address;
            o.SoPhone = phone;
            o.SoPostal = postal;
            o.SoFax = fax;
            o.SoFlag = 0;
            return o;
        }

        private MClient NewClient(string name, string address, string phone, string postal, string fax, MSalesOffice office)
        {
            MClient c = new MClient();
            c.ClName = name;
            c.ClAddress = address;
            c.ClPhone = phone;
            c.ClPostal = postal;
            c.ClFax = fax;
            c.ClFlag = 0;
            c.So = office;
            return c;
        }

        private MEmployee NewEmployee(int id, string name, DateTime hire, string password, string phone,
                                      MSalesOffice office, MPosition position)
        {
            MEmployee e = new MEmployee();
            e.EmId = id;
            e.EmName = name;
            e.EmHiredate = hire;
            e.EmPassword = password;
            e.EmPhone = phone;
            e.EmFlag = 0;
            e.So = office;
            e.Po = position;
            return e;
        }

        private MProduct NewProduct(MMaker maker, MSmallClassification small, string name, decimal price,
                                    int safety, string color, DateTime release)
        {
            MProduct p = new MProduct();
            p.Ma = maker;
            p.Sc = small;
            p.PrName = name;
            p.Price = price;
            p.PrSafetyStock = safety;
            p.PrModelNumber = "1";
            p.PrColor = color;
            p.PrReleaseDate = release;
            p.PrFlag = 0;
            return p;
        }
        // 役職の初期データ（役職がまだない場合だけ登録）
        private void InsertDefaultPositions(SalesManagementContext context)
        {
            if (context.MPositions.Any())
            {
                return;
            }

            List<MPosition> po = new List<MPosition>();
            po.Add(new MPosition() { PoName = "管理者", PoFlag = 0 });
            po.Add(new MPosition() { PoName = "営業", PoFlag = 0 });
            po.Add(new MPosition() { PoName = "物流", PoFlag = 0 });
            context.MPositions.AddRange(po);
            context.SaveChanges();
        }

        // データベースを削除して作り直す（全データが消える）
        private void btn_RecreateDatabase_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "データベースを削除して作り直します。\n" +
                "登録済みのデータはすべて消えます。よろしいですか？",
                "確認", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using SalesManagementContext context = new SalesManagementContext();

                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
                InsertDefaultPositions(context);

                MessageBox.Show("データベースを作り直しました。\n続けて「サンプル登録」を押してください");
            }
            catch (Exception ex)
            {
                MessageBox.Show("データベースの再作成に失敗しました。\n" +
                                "SSMS など他のツールが接続中の場合は、切断してからもう一度お試しください。\n\n" +
                                ex.Message);
            }
        }
    }
}