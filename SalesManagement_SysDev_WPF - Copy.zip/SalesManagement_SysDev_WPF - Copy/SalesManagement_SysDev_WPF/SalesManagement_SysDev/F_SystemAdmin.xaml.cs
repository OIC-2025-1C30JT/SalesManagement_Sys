﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace SalesManagement_SysDev
{
    // 社員権限の閲覧（administrator 専用・読み取りのみ）
    public partial class F_SystemAdmin : Window
    {
        private SystemService service = new SystemService();

        public F_SystemAdmin()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // administrator アカウントだけが使える
            if (!LoginSession.IsAdministrator)
            {
                MessageBox.Show("この画面は administrator だけが使用できます");
                this.Close();
                return;
            }

            lblRoleAdmin.Text = "管理者：" + GetModuleText(LoginSession.RoleAdmin);
            lblRoleLogistics.Text = "物流担当：" + GetModuleText(LoginSession.RoleLogistics);
            lblRoleSales.Text = "営業担当：" + GetModuleText(LoginSession.RoleSales);

            RefreshList();
        }

        // 身分が使えるモジュール名を「、」でつないだ文字にする
        private string GetModuleText(string role)
        {
            List<string> names = new List<string>();
            foreach (string key in ModulePermission.GetAllowedKeys(role))
            {
                names.Add(ModulePermission.GetDisplayName(key));
            }
            return string.Join("、", names);
        }


        private void RefreshList()
        {
            try
            {
                List<EmployeeAdminRow> list =
                    service.GetEmployees(txtFilter.Text.Trim());

                // 使えるモジュールのデータを確認
                foreach (EmployeeAdminRow row in list)
                {
                    System.Diagnostics.Debug.WriteLine(
                        row.ToString()
                    );
                }

                dgEmployee.ItemsSource = null;
                dgEmployee.ItemsSource = list;

                lblCount.Text =
                    "表示件数：" + list.Count + " 件";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "社員の読み込みに失敗しました。\n" +
                    ex.Message);
            }
        }


        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            RefreshList();

            if (dgEmployee.Items.Count == 0)
            {
                MessageBox.Show("該当する社員が見つかりません");
            }
        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            txtFilter.Clear();
            RefreshList();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}