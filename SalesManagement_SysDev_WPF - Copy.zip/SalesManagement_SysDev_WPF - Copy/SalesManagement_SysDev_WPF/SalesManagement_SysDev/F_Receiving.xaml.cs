﻿
using System;
using System.Data;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace SalesManagement_SysDev
{
    public partial class F_Receiving : Window
    {
        private readonly int? _employeeId;

        // ==========================================
        // DataGrid 表示用
        // ==========================================
        private class ArrivalRow
        {
            public int ArId { get; set; }
            public int SoId { get; set; }
            public int? EmId { get; set; }
            public int ClId { get; set; }
            public int OrId { get; set; }

            public DateTime? ArDate { get; set; }
            public int? ArStateFlag { get; set; }

            public string ArrivalDateText
            {
                get
                {
                    return ArDate.HasValue
                        ? ArDate.Value.ToString("yyyy/MM/dd HH:mm:ss")
                        : "未設定";
                }
            }

            public string StatusText
            {
                get
                {
                    return ArStateFlag == 1
                        ? "確定済み"
                        : "未確定";
                }
            }
        }

        // ==========================================
        // Constructor
        // ==========================================
        public F_Receiving(int? employeeId = null)
        {
            InitializeComponent();
            _employeeId = employeeId;
        }

        // ==========================================
        // 画面起動
        // ==========================================
        private void Window_Loaded(
            object sender,
            RoutedEventArgs e)
        {
            DisplayArrivalData();
        }

        // ==========================================
        // 13.1 入荷一覧表示
        // ==========================================
        private void DisplayArrivalData()
        {
            LoadArrivalData();
        }

        private void LoadArrivalData(int? arId = null)
        {
            try
            {
                using var context =
                    new SalesManagementContext();

                var query = context.TArrivals
                    .AsNoTracking()
                    .Where(a => a.ArFlag == 0);

                if (arId.HasValue)
                {
                    query = query.Where(
                        a => a.ArId == arId.Value);
                }

                var arrivals = query
                    .OrderByDescending(a => a.ArId)
                    .ToList();

                var data = arrivals.Select(a =>
                    new ArrivalRow
                    {
                        ArId = a.ArId,
                        SoId = a.SoId,
                        EmId = a.EmId,
                        ClId = a.ClId,
                        OrId = a.OrId,
                        ArDate = a.ArDate,
                        ArStateFlag = a.ArStateFlag
                    })
                    .ToList();

                dgReceiving.ItemsSource = data;
            }
            catch (Exception ex)
            {
                ShowError("入荷一覧取得エラー", ex);
            }
        }

        // ==========================================
        // 一覧表示
        // ==========================================
        private void btnReload_Click(
            object sender,
            RoutedEventArgs e)
        {
            txtSearch.Clear();
            DisplayArrivalData();
        }

        // ==========================================
        // 13.2 入荷検索
        // ==========================================
        private void btnSearch_Click(
            object sender,
            RoutedEventArgs e)
        {
            string keyword = txtSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(keyword))
            {
                DisplayArrivalData();
                return;
            }

            if (!int.TryParse(keyword, out int arId))
            {
                MessageBox.Show(
                    "入荷IDを数字で入力してください。");
                return;
            }

            LoadArrivalData(arId);

            if (dgReceiving.Items.Count == 0)
            {
                MessageBox.Show(
                    "該当データがありません。");
            }
        }

        // ==========================================
        // 13.4 入荷確定
        // ==========================================
        private void btnConfirm_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (dgReceiving.SelectedItem
                is not ArrivalRow selected)
            {
                MessageBox.Show(
                    "入荷データを選択してください。");
                return;
            }

            if (!_employeeId.HasValue)
            {
                MessageBox.Show(
                    "担当社員IDが設定されていません。\n" +
                    "ログイン中の社員IDを渡してください。");
                return;
            }

            if (MessageBox.Show(
                $"入荷ID {selected.ArId} を確定しますか？",
                "入荷確定",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question)
                != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                using var context =
                    new SalesManagementContext();

                bool employeeExists = context.MEmployees
                    .Any(e => e.EmId == _employeeId.Value);

                if (!employeeExists)
                {
                    MessageBox.Show(
                        "ログイン社員IDが社員マスタに存在しません。");
                    return;
                }

                using var transaction =
                    context.Database.BeginTransaction(
                        IsolationLevel.Serializable);

                var arrival = context.TArrivals
                    .Include(a => a.TArrivalDetails)
                    .FirstOrDefault(a =>
                        a.ArId == selected.ArId &&
                        a.ArFlag == 0);

                if (arrival == null)
                {
                    MessageBox.Show(
                        "入荷データが見つかりません。");
                    return;
                }

                if (arrival.ArStateFlag != 0)
                {
                    MessageBox.Show(
                        "この入荷は既に確定済みです。");
                    return;
                }

                var details =
                    arrival.TArrivalDetails.ToList();

                if (details.Count == 0)
                {
                    MessageBox.Show(
                        "入荷詳細がありません。");
                    return;
                }

                if (details.Any(d =>
                    !d.PrId.HasValue ||
                    !d.ArQuantity.HasValue ||
                    d.ArQuantity.Value <= 0))
                {
                    MessageBox.Show(
                        "入荷詳細の商品IDまたは数量が正しくありません。");
                    return;
                }

                if (context.TShipments.Any(s =>
                    s.OrId == arrival.OrId))
                {
                    MessageBox.Show(
                        "この受注の出荷データは既に存在します。");
                    return;
                }

                // ==================================
                // 出荷ヘッダー作成
                // ==================================
                var shipment = new TShipment
                {
                    OrId = arrival.OrId,
                    ClId = arrival.ClId,
                    SoId = arrival.SoId,
                    EmId = null,
                    ShFinishDate = null,
                    ShStateFlag = 0,
                    ShFlag = 0
                };

                // ==================================
                // 出荷詳細作成
                // ==================================
                foreach (var detail in details)
                {
                    shipment.TShipmentDetails.Add(
                        new TShipmentDetail
                        {
                            PrId = detail.PrId.Value,
                            ShQuantity =
                                detail.ArQuantity.Value
                        });
                }

                context.TShipments.Add(shipment);

                // ==================================
                // 入荷確定日時
                // ==================================
                arrival.ArStateFlag = 1;
                arrival.ArDate = DateTime.Now;
                arrival.EmId = _employeeId.Value;

                // Database 保存
                context.SaveChanges();
                transaction.Commit();

                // ==================================
                // 完了メッセージ
                // ==================================
                MessageBox.Show(
                    "入荷確定が完了しました。\n" +
                    "入荷日時: " +
                    arrival.ArDate?.ToString(
                        "yyyy/MM/dd HH:mm:ss") +
                    "\n出荷ID: " + shipment.ShId,
                    "完了",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                // DataGrid 更新
                DisplayArrivalData();
            }
            catch (Exception ex)
            {
                ShowError("入荷確定エラー", ex);
            }
        }


        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "入荷管理画面を閉じますか？",
                "確認",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

        // ==========================================
        // エラー表示
        // ==========================================
        private void ShowError(
            string title,
            Exception ex)
        {
            MessageBox.Show(
                title + ":\n" +
                ex.GetBaseException().Message,
                "エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
